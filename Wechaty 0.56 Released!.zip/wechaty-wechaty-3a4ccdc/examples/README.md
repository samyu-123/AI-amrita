# EXAMPLES

The Wechaty Official Example List Directory has been move to:

<https://github.com/wechaty/wechaty-getting-started/tree/master/examples>

Please use [wechaty-getting-started](https://github.com/wechaty/wechaty-getting-started) repository as the starter template for your project because it can work out-of-the-box with lots of examples.
