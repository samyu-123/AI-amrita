import { Wechaty } from 'wechaty'

console.log(Wechaty.instance().version())
