const { Brolog } = require('brolog')

const brolog = new Brolog()
brolog.info('OK', 'with-require.js')
