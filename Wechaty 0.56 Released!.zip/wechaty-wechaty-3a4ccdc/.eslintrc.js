const rules = {
}

module.exports = {
  extends: '@chatie',
  rules,
}
