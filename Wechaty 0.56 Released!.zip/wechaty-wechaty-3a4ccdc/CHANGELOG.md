
# CHANGELOG

## WECHATY CONTRIBUTORS
### Active Contributors

1. @[lijiarui](https://github.com/lijiarui): [\#2001](https://github.com/wechaty/wechaty/pull/2001) [\#1998](https://github.com/wechaty/wechaty/pull/1998) [\#1876](https://github.com/wechaty/wechaty/pull/1876) [\#1875](https://github.com/wechaty/wechaty/pull/1875) [\#1859](https://github.com/wechaty/wechaty/pull/1859) [\#1702](https://github.com/wechaty/wechaty/pull/1702) [\#1700](https://github.com/wechaty/wechaty/pull/1700) [\#1692](https://github.com/wechaty/wechaty/pull/1692) [\#1633](https://github.com/wechaty/wechaty/pull/1633) [\#1631](https://github.com/wechaty/wechaty/pull/1631) [\#1615](https://github.com/wechaty/wechaty/pull/1615) [\#1614](https://github.com/wechaty/wechaty/pull/1614) [\#1533](https://github.com/wechaty/wechaty/pull/1533) [\#1514](https://github.com/wechaty/wechaty/pull/1514) [\#1510](https://github.com/wechaty/wechaty/pull/1510) [\#1502](https://github.com/wechaty/wechaty/pull/1502) [\#1498](https://github.com/wechaty/wechaty/pull/1498) [\#1497](https://github.com/wechaty/wechaty/pull/1497) [\#1486](https://github.com/wechaty/wechaty/pull/1486) [\#1482](https://github.com/wechaty/wechaty/pull/1482) [\#1481](https://github.com/wechaty/wechaty/pull/1481) [\#1477](https://github.com/wechaty/wechaty/pull/1477) [\#1408](https://github.com/wechaty/wechaty/pull/1408) [\#1407](https://github.com/wechaty/wechaty/pull/1407) [\#1405](https://github.com/wechaty/wechaty/pull/1405) [\#1402](https://github.com/wechaty/wechaty/pull/1402) [\#1375](https://github.com/wechaty/wechaty/pull/1375) [\#1374](https://github.com/wechaty/wechaty/pull/1374) [\#1373](https://github.com/wechaty/wechaty/pull/1373) [\#1352](https://github.com/wechaty/wechaty/pull/1352) [\#1351](https://github.com/wechaty/wechaty/pull/1351) [\#1348](https://github.com/wechaty/wechaty/pull/1348) [\#1347](https://github.com/wechaty/wechaty/pull/1347) [\#1344](https://github.com/wechaty/wechaty/pull/1344) [\#1341](https://github.com/wechaty/wechaty/pull/1341) [\#1338](https://github.com/wechaty/wechaty/pull/1338) [\#1333](https://github.com/wechaty/wechaty/pull/1333) [\#1331](https://github.com/wechaty/wechaty/pull/1331) [\#1325](https://github.com/wechaty/wechaty/pull/1325) [\#1116](https://github.com/wechaty/wechaty/pull/1116) [\#1086](https://github.com/wechaty/wechaty/pull/1086) [\#816](https://github.com/wechaty/wechaty/pull/816) [\#812](https://github.com/wechaty/wechaty/pull/812) [\#805](https://github.com/wechaty/wechaty/pull/805) [\#798](https://github.com/wechaty/wechaty/pull/798) [\#757](https://github.com/wechaty/wechaty/pull/757) [\#725](https://github.com/wechaty/wechaty/pull/725) [\#440](https://github.com/wechaty/wechaty/pull/440) [\#370](https://github.com/wechaty/wechaty/pull/370) [\#364](https://github.com/wechaty/wechaty/pull/364) [\#362](https://github.com/wechaty/wechaty/pull/362) [\#328](https://github.com/wechaty/wechaty/pull/328) [\#324](https://github.com/wechaty/wechaty/pull/324) [\#323](https://github.com/wechaty/wechaty/pull/323) [\#321](https://github.com/wechaty/wechaty/pull/321) [\#318](https://github.com/wechaty/wechaty/pull/318) [\#303](https://github.com/wechaty/wechaty/pull/303) [\#292](https://github.com/wechaty/wechaty/pull/292) [\#139](https://github.com/wechaty/wechaty/pull/139) [\#112](https://github.com/wechaty/wechaty/pull/112) [\#110](https://github.com/wechaty/wechaty/pull/110) [\#38](https://github.com/wechaty/wechaty/pull/38)
1. @[huan](https://github.com/huan): [\#2028](https://github.com/wechaty/wechaty/pull/2028) [\#2021](https://github.com/wechaty/wechaty/pull/2021) [\#1931](https://github.com/wechaty/wechaty/pull/1931) [\#1888](https://github.com/wechaty/wechaty/pull/1888) [\#1870](https://github.com/wechaty/wechaty/pull/1870) [\#1782](https://github.com/wechaty/wechaty/pull/1782) [\#1597](https://github.com/wechaty/wechaty/pull/1597) [\#1143](https://github.com/wechaty/wechaty/pull/1143) [\#1131](https://github.com/wechaty/wechaty/pull/1131) [\#1083](https://github.com/wechaty/wechaty/pull/1083) [\#1075](https://github.com/wechaty/wechaty/pull/1075) [\#1074](https://github.com/wechaty/wechaty/pull/1074) [\#1073](https://github.com/wechaty/wechaty/pull/1073) [\#1072](https://github.com/wechaty/wechaty/pull/1072) [\#1071](https://github.com/wechaty/wechaty/pull/1071) [\#860](https://github.com/wechaty/wechaty/pull/860) [\#854](https://github.com/wechaty/wechaty/pull/854) [\#841](https://github.com/wechaty/wechaty/pull/841) [\#831](https://github.com/wechaty/wechaty/pull/831) [\#810](https://github.com/wechaty/wechaty/pull/810) [\#469](https://github.com/wechaty/wechaty/pull/469) [\#462](https://github.com/wechaty/wechaty/pull/462) [\#455](https://github.com/wechaty/wechaty/pull/455) [\#449](https://github.com/wechaty/wechaty/pull/449) [\#396](https://github.com/wechaty/wechaty/pull/396) [\#351](https://github.com/wechaty/wechaty/pull/351) [\#317](https://github.com/wechaty/wechaty/pull/317) [\#316](https://github.com/wechaty/wechaty/pull/316) [\#315](https://github.com/wechaty/wechaty/pull/315) [\#314](https://github.com/wechaty/wechaty/pull/314) [\#313](https://github.com/wechaty/wechaty/pull/313) [\#312](https://github.com/wechaty/wechaty/pull/312) [\#311](https://github.com/wechaty/wechaty/pull/311) [\#168](https://github.com/wechaty/wechaty/pull/168) [\#158](https://github.com/wechaty/wechaty/pull/158) [\#149](https://github.com/wechaty/wechaty/pull/149) [\#146](https://github.com/wechaty/wechaty/pull/146) [\#143](https://github.com/wechaty/wechaty/pull/143) [\#142](https://github.com/wechaty/wechaty/pull/142) [\#141](https://github.com/wechaty/wechaty/pull/141) [\#25](https://github.com/wechaty/wechaty/pull/25)
1. @[windmemory](https://github.com/windmemory): [\#1832](https://github.com/wechaty/wechaty/pull/1832) [\#1770](https://github.com/wechaty/wechaty/pull/1770) [\#1735](https://github.com/wechaty/wechaty/pull/1735) [\#1729](https://github.com/wechaty/wechaty/pull/1729) [\#1662](https://github.com/wechaty/wechaty/pull/1662) [\#1660](https://github.com/wechaty/wechaty/pull/1660) [\#1643](https://github.com/wechaty/wechaty/pull/1643) [\#1630](https://github.com/wechaty/wechaty/pull/1630) [\#1577](https://github.com/wechaty/wechaty/pull/1577) [\#1571](https://github.com/wechaty/wechaty/pull/1571) [\#1557](https://github.com/wechaty/wechaty/pull/1557) [\#1550](https://github.com/wechaty/wechaty/pull/1550) [\#1538](https://github.com/wechaty/wechaty/pull/1538) [\#1526](https://github.com/wechaty/wechaty/pull/1526) [\#1503](https://github.com/wechaty/wechaty/pull/1503) [\#1457](https://github.com/wechaty/wechaty/pull/1457)
1. @[su-chang](https://github.com/su-chang): [\#2012](https://github.com/wechaty/wechaty/pull/2012) [\#2011](https://github.com/wechaty/wechaty/pull/2011) [\#1936](https://github.com/wechaty/wechaty/pull/1936) [\#1921](https://github.com/wechaty/wechaty/pull/1921) [\#1915](https://github.com/wechaty/wechaty/pull/1915) [\#1913](https://github.com/wechaty/wechaty/pull/1913) [\#1910](https://github.com/wechaty/wechaty/pull/1910) [\#1900](https://github.com/wechaty/wechaty/pull/1900) [\#1895](https://github.com/wechaty/wechaty/pull/1895) [\#1883](https://github.com/wechaty/wechaty/pull/1883) [\#1868](https://github.com/wechaty/wechaty/pull/1868) [\#1866](https://github.com/wechaty/wechaty/pull/1866) [\#1864](https://github.com/wechaty/wechaty/pull/1864) [\#1861](https://github.com/wechaty/wechaty/pull/1861) [\#1833](https://github.com/wechaty/wechaty/pull/1833)
1. @[mukaiu](https://github.com/mukaiu): [\#1089](https://github.com/wechaty/wechaty/pull/1089) [\#337](https://github.com/wechaty/wechaty/pull/337) [\#470](https://github.com/wechaty/wechaty/pull/470) [\#438](https://github.com/wechaty/wechaty/pull/438) [\#421](https://github.com/wechaty/wechaty/pull/421) [\#420](https://github.com/wechaty/wechaty/pull/420) [\#415](https://github.com/wechaty/wechaty/pull/415) [\#376](https://github.com/wechaty/wechaty/pull/376)
1. @[JasLin](https://github.com/JasLin): [\#404](https://github.com/wechaty/wechaty/pull/404) [\#358](https://github.com/wechaty/wechaty/pull/358) [\#105](https://github.com/wechaty/wechaty/pull/105) [\#100](https://github.com/wechaty/wechaty/pull/100) [\#78](https://github.com/wechaty/wechaty/pull/78) [\#76](https://github.com/wechaty/wechaty/pull/76)
1. @[kis87988](https://github.com/kis87988): [\#1993](https://github.com/wechaty/wechaty/pull/1993) [\#1908](https://github.com/wechaty/wechaty/pull/1908) [\#1623](https://github.com/wechaty/wechaty/pull/1623) [\#1607](https://github.com/wechaty/wechaty/pull/1607) [\#1570](https://github.com/wechaty/wechaty/pull/1570)
1. @[xinbenlv](https://github.com/xinbenlv): [\#1814](https://github.com/wechaty/wechaty/pull/1814) [\#1017](https://github.com/wechaty/wechaty/pull/1017) [\#935](https://github.com/wechaty/wechaty/pull/935) [\#388](https://github.com/wechaty/wechaty/pull/388) [\#361](https://github.com/wechaty/wechaty/pull/361)
1. @[binsee](https://github.com/binsee): [\#844](https://github.com/wechaty/wechaty/pull/844) [\#811](https://github.com/wechaty/wechaty/pull/811) [\#771](https://github.com/wechaty/wechaty/pull/771) [\#744](https://github.com/wechaty/wechaty/pull/744) [\#727](https://github.com/wechaty/wechaty/pull/727)
1. @[linyimin-bupt](https://github.com/linyimin-bupt): [\#1757](https://github.com/wechaty/wechaty/pull/1757) [\#1752](https://github.com/wechaty/wechaty/pull/1752) [\#1750](https://github.com/wechaty/wechaty/pull/1750) [\#1749](https://github.com/wechaty/wechaty/pull/1749)
1. @[TbhT](https://github.com/TbhT): [\#1713](https://github.com/wechaty/wechaty/pull/1713) [\#1583](https://github.com/wechaty/wechaty/pull/1583) [\#1582](https://github.com/wechaty/wechaty/pull/1582)
1. @[suntong](https://github.com/suntong): [\#1677](https://github.com/wechaty/wechaty/pull/1677) [\#1129](https://github.com/wechaty/wechaty/pull/1129) [\#1123](https://github.com/wechaty/wechaty/pull/1123)
1. @[Gcaufy](https://github.com/Gcaufy): [\#1625](https://github.com/wechaty/wechaty/pull/1625) [\#1620](https://github.com/wechaty/wechaty/pull/1620) [\#310](https://github.com/wechaty/wechaty/pull/310)
1. @[plainheart](https://github.com/plainheart): [\#2000](https://github.com/wechaty/wechaty/pull/2000) [\#1999](https://github.com/wechaty/wechaty/pull/1999)
1. @[ax4](https://github.com/ax4): [\#1994](https://github.com/wechaty/wechaty/pull/1994) [\#380](https://github.com/wechaty/wechaty/pull/380)
1. @[SilentQianyi](https://github.com/SilentQianyi): [\#1891](https://github.com/wechaty/wechaty/pull/1891) [\#1886](https://github.com/wechaty/wechaty/pull/1886)
1. @[LinuxSuRen](https://github.com/LinuxSuRen): [\#1838](https://github.com/wechaty/wechaty/pull/1838) [\#1836](https://github.com/wechaty/wechaty/pull/1836)

### Contributors

1. @[lucifer1004](https://github.com/lucifer1004): [\#1989](https://github.com/wechaty/wechaty/pull/1989)
1. @[rikakomoe](https://github.com/rikakomoe): [\#1904](https://github.com/wechaty/wechaty/pull/1904)
1. @[LanceZhu](https://github.com/LanceZhu): [\#1854](https://github.com/wechaty/wechaty/pull/1854)
1. @[zhaoic](https://github.com/zhaoic): [\#1822](https://github.com/wechaty/wechaty/pull/1822)
1. @[coderwhocode](https://github.com/coderwhocode): [\#1819](https://github.com/wechaty/wechaty/pull/1819)
1. @[gengchen528](https://github.com/gengchen528): [\#1818](https://github.com/wechaty/wechaty/pull/1818)
1. @[monkeywithacupcake](https://github.com/monkeywithacupcake): [\#1759](https://github.com/wechaty/wechaty/pull/1759)
1. @[lhr0909](https://github.com/lhr0909): [\#1666](https://github.com/wechaty/wechaty/pull/1666)
1. @[jzj1993](https://github.com/jzj1993): [\#1661](https://github.com/wechaty/wechaty/pull/1661)
1. @[bitwater](https://github.com/bitwater): [\#1532](https://github.com/wechaty/wechaty/pull/1532)
1. @[IdiosApps](https://github.com/IdiosApps): [\#1087](https://github.com/wechaty/wechaty/pull/1087)
1. @[hiwanz](https://github.com/hiwanz): [\#1036](https://github.com/wechaty/wechaty/pull/1036)
1. @[htoooth](https://github.com/htoooth): [\#1014](https://github.com/wechaty/wechaty/pull/1014)
1. @[zhenyong](https://github.com/zhenyong): [\#770](https://github.com/wechaty/wechaty/pull/770)
1. @[xjchengo](https://github.com/xjchengo): [\#416](https://github.com/wechaty/wechaty/pull/416)
1. @[cherry-geqi](https://github.com/cherry-geqi): [\#97](https://github.com/wechaty/wechaty/pull/97)

# Changelog

## [Unreleased](https://github.com/wechaty/wechaty/tree/HEAD)

[Full Changelog](https://github.com/wechaty/wechaty/compare/v0.38...HEAD)

**Implemented enhancements:**

- Refactoring Multi-instance Wechaty Design: Try to remove the Accessory class and related codes [\#2027](https://github.com/wechaty/wechaty/issues/2027)
- Use Typed-Emitter in Wechaty [\#2014](https://github.com/wechaty/wechaty/issues/2014)
- Support WECHATY\_HOSTIE\_PORT environment variable [\#1984](https://github.com/wechaty/wechaty/issues/1984)
- Wechaty v0.23 PadPro Testing, an enhanced pad puppet implementation!  [\#1668](https://github.com/wechaty/wechaty/issues/1668)

**Fixed bugs:**

- Wechaty.off\(\) not work: can not remove listeners. [\#2019](https://github.com/wechaty/wechaty/issues/2019)
- friendship.contact\(\) will load Contact only, contact.ready\(\) is wanted. [\#1954](https://github.com/wechaty/wechaty/issues/1954)

**Closed issues:**

- BREAKING CHANGES: remove hotImport support from wechaty [\#1997](https://github.com/wechaty/wechaty/issues/1997)
- ERR GRPC\_GATEWAY GRPC SERVER ERROR [\#1996](https://github.com/wechaty/wechaty/issues/1996)
- 微信安装 [\#1990](https://github.com/wechaty/wechaty/issues/1990)
- Cannot read property 'QQ' of undefined [\#1982](https://github.com/wechaty/wechaty/issues/1982)
- Need upgrade wechaty-puppet@0.25.7 version for wechaty [\#1980](https://github.com/wechaty/wechaty/issues/1980)
- The qrcode all the time timeout [\#1977](https://github.com/wechaty/wechaty/issues/1977)
- Upgrade wechaty-puppet-hostie@0.7.10 for fix the bug of friendship.accpet\(\) [\#1966](https://github.com/wechaty/wechaty/issues/1966)
- 23:42:53 SILL GrpcGateway callback type:【invalid-token】 [\#1959](https://github.com/wechaty/wechaty/issues/1959)
- 准备支持企业微信群吗 [\#1958](https://github.com/wechaty/wechaty/issues/1958)
- node-pre-gyp WARN  [\#1953](https://github.com/wechaty/wechaty/issues/1953)
- How to filter official account numbers [\#1951](https://github.com/wechaty/wechaty/issues/1951)
- Update wechaty-puppet-hostie version for wechaty [\#1948](https://github.com/wechaty/wechaty/issues/1948)
- Is that you? [\#1942](https://github.com/wechaty/wechaty/issues/1942)
- New version release notes for wechaty 0.38 [\#1937](https://github.com/wechaty/wechaty/issues/1937)
- Can the receive the recall " room-leave". [\#1745](https://github.com/wechaty/wechaty/issues/1745)

**Merged pull requests:**

- remove Accessories by wechatify user classes [\#2028](https://github.com/wechaty/wechaty/pull/2028) ([huan](https://github.com/huan))
- fix event listener [\#2021](https://github.com/wechaty/wechaty/pull/2021) ([huan](https://github.com/huan))
- Upgrade hostie [\#2012](https://github.com/wechaty/wechaty/pull/2012) ([su-chang](https://github.com/su-chang))
- Upgrade hostie [\#2011](https://github.com/wechaty/wechaty/pull/2011) ([su-chang](https://github.com/su-chang))
- Update README.md [\#2001](https://github.com/wechaty/wechaty/pull/2001) ([lijiarui](https://github.com/lijiarui))
- docs: fixed table format flaw of `Message.say` in README.md. [\#2000](https://github.com/wechaty/wechaty/pull/2000) ([plainheart](https://github.com/plainheart))
- docs: fixed table format flaw of `Contact.say` in README.md. [\#1999](https://github.com/wechaty/wechaty/pull/1999) ([plainheart](https://github.com/plainheart))
- Update README.md [\#1998](https://github.com/wechaty/wechaty/pull/1998) ([lijiarui](https://github.com/lijiarui))
- fix: fix the broken URLs links to /bot-qr-code.png [\#1994](https://github.com/wechaty/wechaty/pull/1994) ([ax4](https://github.com/ax4))
- test: update workflows for node ^12 [\#1993](https://github.com/wechaty/wechaty/pull/1993) ([kis87988](https://github.com/kis87988))
- fix: typo in README.md [\#1989](https://github.com/wechaty/wechaty/pull/1989) ([lucifer1004](https://github.com/lucifer1004))

## [v0.38](https://github.com/wechaty/wechaty/tree/v0.38) (2020-04-08)

[Full Changelog](https://github.com/wechaty/wechaty/compare/v0.30...v0.38)

**Implemented enhancements:**

- BREAKING CHANGE: Remove `MessageUserQueryFilter` [\#1929](https://github.com/wechaty/wechaty/issues/1929)
- Simplify the Accessory class logic [\#1924](https://github.com/wechaty/wechaty/issues/1924)
- Update Docker Base Image form Ubuntu:18 to Ubuntu:19 [\#1920](https://github.com/wechaty/wechaty/issues/1920)
- wechaty dependency modules deep cleaning [\#1917](https://github.com/wechaty/wechaty/issues/1917)
- FileBox version incompatible across wechaty wechaty-puppet and wechaty-puppet-x  [\#1914](https://github.com/wechaty/wechaty/issues/1914)
- Publish Wechaty Document Site to https://wechaty.js.org [\#1912](https://github.com/wechaty/wechaty/issues/1912)
- Support Encode & Decode QR Code functions from file-box@0.10 [\#1907](https://github.com/wechaty/wechaty/issues/1907)
- Design an new `Image` class for receive images with different sizes. [\#1871](https://github.com/wechaty/wechaty/issues/1871)
- Integrate Wechat with Matrix with the power of Wechaty [\#1737](https://github.com/wechaty/wechaty/issues/1737)

**Fixed bugs:**

- Can not create Image class. [\#1922](https://github.com/wechaty/wechaty/issues/1922)

**Closed issues:**

- 微信退出登录后，重新登录不了ipad [\#1839](https://github.com/wechaty/wechaty/issues/1839)
- 基于padpro协议不能发送微信小程序 [\#1837](https://github.com/wechaty/wechaty/issues/1837)

**Merged pull requests:**

- 0.38.0 [\#1936](https://github.com/wechaty/wechaty/pull/1936) ([su-chang](https://github.com/su-chang))
- Remove MessageUserQueryFilter [\#1931](https://github.com/wechaty/wechaty/pull/1931) ([huan](https://github.com/huan))
- Image bug [\#1921](https://github.com/wechaty/wechaty/pull/1921) ([su-chang](https://github.com/su-chang))
- File box [\#1915](https://github.com/wechaty/wechaty/pull/1915) ([su-chang](https://github.com/su-chang))
- Support message.toImage\(\) method. [\#1913](https://github.com/wechaty/wechaty/pull/1913) ([su-chang](https://github.com/su-chang))
- Support delay to accept room invitation [\#1910](https://github.com/wechaty/wechaty/pull/1910) ([su-chang](https://github.com/su-chang))

## [v0.30](https://github.com/wechaty/wechaty/tree/v0.30) (2020-02-08)

[Full Changelog](https://github.com/wechaty/wechaty/compare/v0.28...v0.30)

**Implemented enhancements:**

- Support room.say`hi ${contact} ${num++}` [\#1899](https://github.com/wechaty/wechaty/issues/1899)
- Support new event named "message" on Room [\#1897](https://github.com/wechaty/wechaty/issues/1897)
- Support search new friends by phone number or user name. [\#1892](https://github.com/wechaty/wechaty/issues/1892)
- {Room,Contact}.qrcode\(\) should return QR Code Value instead of Image [\#1889](https://github.com/wechaty/wechaty/issues/1889)
- Implmented UrlLink.create\(url\) with Open Graph support [\#1887](https://github.com/wechaty/wechaty/issues/1887)
- 主动撤回消息 [\#1885](https://github.com/wechaty/wechaty/issues/1885)
- Implement Label in Wechaty [\#1856](https://github.com/wechaty/wechaty/issues/1856)
- Would like to have the timestamp on the room/friendship events [\#1829](https://github.com/wechaty/wechaty/issues/1829)
- Wechaty v0.26 iosBird Testing, an iOS hook puppet implementation! [\#1775](https://github.com/wechaty/wechaty/issues/1775)
- Missing example code [\#1756](https://github.com/wechaty/wechaty/issues/1756)
- BREAKING CHANGE v0.25 Room.say\(text: string, mention: Contact\[\]\) deprecated [\#1730](https://github.com/wechaty/wechaty/issues/1730)
- New Puppet: Ioscat \(iPhone Wechat App Hook\) [\#1528](https://github.com/wechaty/wechaty/issues/1528)

**Fixed bugs:**

- bot.logonoff\(\)报错【static puppet not found for Wechaty】 [\#1878](https://github.com/wechaty/wechaty/issues/1878)
- JSDoc publishing problem: missed the Room class [\#1872](https://github.com/wechaty/wechaty/issues/1872)
- Wechaty can not get room info when the bot has been removed from one room. [\#1834](https://github.com/wechaty/wechaty/issues/1834)
- bot.Contact.find\(\) error message misleading [\#1812](https://github.com/wechaty/wechaty/issues/1812)
- 机器人会隔一段时间自动退出 [\#1810](https://github.com/wechaty/wechaty/issues/1810)

**Closed issues:**

- room.announce\(\)中当参数为空字符串时, 调用获取群公告而不是设置群公告为空 [\#1902](https://github.com/wechaty/wechaty/issues/1902)
- 延期通过好友 [\#1890](https://github.com/wechaty/wechaty/issues/1890)
- I want wechaty puppet padpro token to create a wechat bot [\#1882](https://github.com/wechaty/wechaty/issues/1882)
- msg.mentionSelf\(\)方法不对，始终返回false [\#1877](https://github.com/wechaty/wechaty/issues/1877)
- 需要取到Contactid或者微信号 [\#1873](https://github.com/wechaty/wechaty/issues/1873)
- Function message `toContact\(\)` should to be implemented. [\#1855](https://github.com/wechaty/wechaty/issues/1855)
- install error [\#1853](https://github.com/wechaty/wechaty/issues/1853)
- wechaty-puppet can not install in electron [\#1851](https://github.com/wechaty/wechaty/issues/1851)
- wechaty-puppet-macpro alpha test [\#1846](https://github.com/wechaty/wechaty/issues/1846)
- Action required: Greenkeeper could not be activated 🚨 [\#1781](https://github.com/wechaty/wechaty/issues/1781)
- 经常报以下warning [\#1634](https://github.com/wechaty/wechaty/issues/1634)
- Doesn't work with UK Android account/device [\#1556](https://github.com/wechaty/wechaty/issues/1556)

**Merged pull requests:**

- fix: wechaty-puppet-dll temporary unavailable [\#1908](https://github.com/wechaty/wechaty/pull/1908) ([kis87988](https://github.com/kis87988))
- docs: improve ding-dong-bot example [\#1904](https://github.com/wechaty/wechaty/pull/1904) ([rikakomoe](https://github.com/rikakomoe))
- Add reason for logout event [\#1900](https://github.com/wechaty/wechaty/pull/1900) ([su-chang](https://github.com/su-chang))
- Friend search [\#1895](https://github.com/wechaty/wechaty/pull/1895) ([su-chang](https://github.com/su-chang))
- Delay friendship [\#1891](https://github.com/wechaty/wechaty/pull/1891) ([SilentQianyi](https://github.com/SilentQianyi))
- Create url link [\#1888](https://github.com/wechaty/wechaty/pull/1888) ([huan](https://github.com/huan))
- Recall msg [\#1886](https://github.com/wechaty/wechaty/pull/1886) ([SilentQianyi](https://github.com/SilentQianyi))
- Change Mini Program payload in wechaty [\#1883](https://github.com/wechaty/wechaty/pull/1883) ([su-chang](https://github.com/su-chang))
- Update README.md [\#1876](https://github.com/wechaty/wechaty/pull/1876) ([lijiarui](https://github.com/lijiarui))
- add kaiyuanshe bot [\#1875](https://github.com/wechaty/wechaty/pull/1875) ([lijiarui](https://github.com/lijiarui))
- chore\(package\): update @types/node to version 12.12.3 [\#1870](https://github.com/wechaty/wechaty/pull/1870) ([huan](https://github.com/huan))
- Implement toContact\(\) method [\#1868](https://github.com/wechaty/wechaty/pull/1868) ([su-chang](https://github.com/su-chang))
- feat: change say\(\) method response type from void to Message [\#1866](https://github.com/wechaty/wechaty/pull/1866) ([su-chang](https://github.com/su-chang))
- Implement Label related methods [\#1864](https://github.com/wechaty/wechaty/pull/1864) ([su-chang](https://github.com/su-chang))
- Update contact.ts [\#1861](https://github.com/wechaty/wechaty/pull/1861) ([su-chang](https://github.com/su-chang))
- fix opencollective Sponsors style [\#1859](https://github.com/wechaty/wechaty/pull/1859) ([lijiarui](https://github.com/lijiarui))
- fix typo [\#1854](https://github.com/wechaty/wechaty/pull/1854) ([LanceZhu](https://github.com/LanceZhu))
- Update wechaty.ts [\#1833](https://github.com/wechaty/wechaty/pull/1833) ([su-chang](https://github.com/su-chang))

## [v0.28](https://github.com/wechaty/wechaty/tree/v0.28) (2019-09-02)

[Full Changelog](https://github.com/wechaty/wechaty/compare/v0.26.0...v0.28)

**Implemented enhancements:**

- Room announcement is not working properly for some puppet implementation [\#1816](https://github.com/wechaty/wechaty/issues/1816)
- \[Feature\] Send Mini-Program  [\#1806](https://github.com/wechaty/wechaty/issues/1806)
- Upgrade the repo to use Chatie DevOps toolset [\#1793](https://github.com/wechaty/wechaty/issues/1793)
- Easy install for wechaty-puppet-puppeteer [\#1792](https://github.com/wechaty/wechaty/issues/1792)
- 添加用 id 寻找Room RoomQueryFilter [\#1785](https://github.com/wechaty/wechaty/issues/1785)
- Generate version.ts before publish to NPM [\#1780](https://github.com/wechaty/wechaty/issues/1780)
- Use `@chatie/tsconfig` as the tsconfig.json base configuration [\#1777](https://github.com/wechaty/wechaty/issues/1777)
- Could you please upgrade dependency for wechaty-puppet-puppeteer [\#1758](https://github.com/wechaty/wechaty/issues/1758)
- Missing comment example code in room.ts file [\#1751](https://github.com/wechaty/wechaty/issues/1751)

**Fixed bugs:**

- missing puppets in latest docker image [\#1820](https://github.com/wechaty/wechaty/issues/1820)
- Cannot `Contact.say\(imageAsFileBox\)` with puppeteer [\#1795](https://github.com/wechaty/wechaty/issues/1795)
- Document bug in README [\#1690](https://github.com/wechaty/wechaty/issues/1690)
- Fix comment, in replacing \#1784 [\#1814](https://github.com/wechaty/wechaty/pull/1814) ([xinbenlv](https://github.com/xinbenlv))

**Closed issues:**

- 登录不了一个错误报告 [\#1841](https://github.com/wechaty/wechaty/issues/1841)
- 想获取微信消息列表，Message.findAll\(\)返回为空？ [\#1825](https://github.com/wechaty/wechaty/issues/1825)
- 用了一个月itchat相安无事，用了2小时wechaty... [\#1815](https://github.com/wechaty/wechaty/issues/1815)
- Wechaty process.exit\(1\) if token is not valid [\#1811](https://github.com/wechaty/wechaty/issues/1811)
- TSError: ⨯ Unable to compile TypeScript: [\#1791](https://github.com/wechaty/wechaty/issues/1791)
- padpro 无法连接服务器 [\#1789](https://github.com/wechaty/wechaty/issues/1789)
- Action required: Greenkeeper could not be activated 🚨 [\#1765](https://github.com/wechaty/wechaty/issues/1765)
- Mention api add @ automatically no matter it is already exists in the text [\#1718](https://github.com/wechaty/wechaty/issues/1718)

**Merged pull requests:**

- Update the ipad protocol environment [\#1838](https://github.com/wechaty/wechaty/pull/1838) ([LinuxSuRen](https://github.com/LinuxSuRen))
- Update link for wechaty-puppet-padchat [\#1836](https://github.com/wechaty/wechaty/pull/1836) ([LinuxSuRen](https://github.com/LinuxSuRen))
- Add timestamp to events [\#1832](https://github.com/wechaty/wechaty/pull/1832) ([windmemory](https://github.com/windmemory))
- Send MiniProgram using PadPro [\#1822](https://github.com/wechaty/wechaty/pull/1822) ([zhaoic](https://github.com/zhaoic))
- Add Readme - powered by wechaty example [\#1819](https://github.com/wechaty/wechaty/pull/1819) ([coderwhocode](https://github.com/coderwhocode))
- 添加项目案例微信小助手 [\#1818](https://github.com/wechaty/wechaty/pull/1818) ([gengchen528](https://github.com/gengchen528))
- chore\(package\): update dependencies [\#1782](https://github.com/wechaty/wechaty/pull/1782) ([huan](https://github.com/huan))

## [v0.26.0](https://github.com/wechaty/wechaty/tree/v0.26.0) (2019-05-11)

[Full Changelog](https://github.com/wechaty/wechaty/compare/v0.22.4...v0.26.0)

**Implemented enhancements:**

- Recalled message design [\#1728](https://github.com/wechaty/wechaty/issues/1728)
- Message.toString format discussion [\#1676](https://github.com/wechaty/wechaty/issues/1676)
- Upgrade wechaty-puppet-padchat stable version [\#1642](https://github.com/wechaty/wechaty/issues/1642)
- New Puppet - wechaty-puppet-padpro [\#1629](https://github.com/wechaty/wechaty/issues/1629)
- room mention contact should using roomAlias [\#1604](https://github.com/wechaty/wechaty/issues/1604)
- for Pull Request: Disable puppet unit tests that requires a token [\#1580](https://github.com/wechaty/wechaty/issues/1580)
- Refresh contact self when updating self name or signature [\#1576](https://github.com/wechaty/wechaty/issues/1576)
- Pass mention list down to puppets [\#1560](https://github.com/wechaty/wechaty/issues/1560)
- Wechaty Puppet Ioscat Testing:  iPhone\(iOS\) Wechat Hooking Support are comming! [\#1530](https://github.com/wechaty/wechaty/issues/1530)

**Fixed bugs:**

- Room.owner\(\) function is printing log in info level [\#1769](https://github.com/wechaty/wechaty/issues/1769)
- Build is failing caused by promisify missing arg3 [\#1761](https://github.com/wechaty/wechaty/issues/1761)
- Comment: Example code error [\#1746](https://github.com/wechaty/wechaty/issues/1746)
- Documentation网站挂掉了 [\#1739](https://github.com/wechaty/wechaty/issues/1739)
- 构建docker镜像报错 [\#1593](https://github.com/wechaty/wechaty/issues/1593)
- memberAll\(\) not running in docker after v0.21.27 [\#1573](https://github.com/wechaty/wechaty/issues/1573)
-  ERR PuppetPuppeteer roomRawPayload [\#1547](https://github.com/wechaty/wechaty/issues/1547)

**Closed issues:**

- invalid processingToken:make the account logout.. [\#1766](https://github.com/wechaty/wechaty/issues/1766)
- Action required: Greenkeeper could not be activated 🚨 [\#1764](https://github.com/wechaty/wechaty/issues/1764)
- Action required: Greenkeeper could not be activated 🚨 [\#1763](https://github.com/wechaty/wechaty/issues/1763)
- \[已解决\]无法自动通过好友请求 [\#1755](https://github.com/wechaty/wechaty/issues/1755)
- Missing comment example code in contact.ts file [\#1748](https://github.com/wechaty/wechaty/issues/1748)
- Is there a way to send message to a contact instead of making a reply using say\(\)? [\#1734](https://github.com/wechaty/wechaty/issues/1734)
- await message.mentionSelf\(\) is invalid [\#1725](https://github.com/wechaty/wechaty/issues/1725)
- message.mentionSelf\(\) [\#1724](https://github.com/wechaty/wechaty/issues/1724)
- wechaty-puppet-padpro 获得的语音消息文件是slk格式 [\#1720](https://github.com/wechaty/wechaty/issues/1720)
- 有没有针对企业微信App的登录和收发消息的方案啊？ [\#1717](https://github.com/wechaty/wechaty/issues/1717)
- 关于win7安装 npm install wechaty-puppet-padpro 的问题 [\#1716](https://github.com/wechaty/wechaty/issues/1716)
- 小桔机器人挺好用，希望详细对比WeTools，并分享开发Roadmap，谢谢 [\#1712](https://github.com/wechaty/wechaty/issues/1712)
- npm start 到 puppeteer@1.12.2  报错。。。 [\#1708](https://github.com/wechaty/wechaty/issues/1708)
- 这是什么 [\#1703](https://github.com/wechaty/wechaty/issues/1703)
- 使用自动拉人入群功能 [\#1697](https://github.com/wechaty/wechaty/issues/1697)
- docker compose [\#1688](https://github.com/wechaty/wechaty/issues/1688)
- Errors occur sometimes when bot running [\#1675](https://github.com/wechaty/wechaty/issues/1675)
- msg.say 重复执行 [\#1674](https://github.com/wechaty/wechaty/issues/1674)
- WECHATY\_PUPPET=mock failed, TypeError \[ERR\_INVALID\_ARG\_TYPE\]: The "request" argument must be of type string [\#1673](https://github.com/wechaty/wechaty/issues/1673)
- Room.say method is not working [\#1665](https://github.com/wechaty/wechaty/issues/1665)
- 这是基于什么协议的web pc ipad [\#1664](https://github.com/wechaty/wechaty/issues/1664)
- Adjust data sync order when message event triggered [\#1659](https://github.com/wechaty/wechaty/issues/1659)
- 乱码 [\#1656](https://github.com/wechaty/wechaty/issues/1656)
- 乱码 [\#1655](https://github.com/wechaty/wechaty/issues/1655)
- ipad [\#1650](https://github.com/wechaty/wechaty/issues/1650)
- \[RFC\] custom id on Contact [\#1647](https://github.com/wechaty/wechaty/issues/1647)
- 请问， 怎么让机器人通过手机号添加好友 [\#1639](https://github.com/wechaty/wechaty/issues/1639)
- 请问wechaty可以关掉日志输出吗？ [\#1638](https://github.com/wechaty/wechaty/issues/1638)
- ubuntu 18.04下无法正常启动chrome [\#1637](https://github.com/wechaty/wechaty/issues/1637)
- 在docker容器中，npm install wechaty，运行mybot报错：Failed to launch chrome! [\#1636](https://github.com/wechaty/wechaty/issues/1636)
- Why I stuck here? [\#1624](https://github.com/wechaty/wechaty/issues/1624)
- can robot join room by qrcode？ [\#1622](https://github.com/wechaty/wechaty/issues/1622)
- 调用私发/群内发消息接口，emit出的消息事件中消息时间有误 [\#1619](https://github.com/wechaty/wechaty/issues/1619)
- 调用发消息接口后，emit 出的消息事件对应的消息时间不正确 [\#1617](https://github.com/wechaty/wechaty/issues/1617)
- room.on\('join',function\(room, inviteeList, inviter\)\), can not get the inviteeList i.e. the new member [\#1613](https://github.com/wechaty/wechaty/issues/1613)
- cgggg [\#1610](https://github.com/wechaty/wechaty/issues/1610)
- c [\#1609](https://github.com/wechaty/wechaty/issues/1609)
- I use this function keyroom.add\(contact\),it doesn't work [\#1601](https://github.com/wechaty/wechaty/issues/1601)
- use "wechaty-puppet-padchat" cannot login successfully [\#1600](https://github.com/wechaty/wechaty/issues/1600)
- wechaty无法查找到群名称中有~的群 [\#1592](https://github.com/wechaty/wechaty/issues/1592)
- Sending messages with MessageType=1 is not supported [\#1588](https://github.com/wechaty/wechaty/issues/1588)
- 不能通过群成员添加好友 [\#1578](https://github.com/wechaty/wechaty/issues/1578)
- \[RFC\] Launch broken when using wechaty-puppet-padchat [\#1575](https://github.com/wechaty/wechaty/issues/1575)
- Delete the `breaking change` tag in issue [\#1565](https://github.com/wechaty/wechaty/issues/1565)

**Merged pull requests:**

- Change room.owner\(\) log from info level to verbose level [\#1770](https://github.com/wechaty/wechaty/pull/1770) ([windmemory](https://github.com/windmemory))
- Activating Open Collective [\#1759](https://github.com/wechaty/wechaty/pull/1759) ([monkeywithacupcake](https://github.com/monkeywithacupcake))
- add example code [\#1757](https://github.com/wechaty/wechaty/pull/1757) ([linyimin-bupt](https://github.com/linyimin-bupt))
- add send urlLink example code in room class [\#1752](https://github.com/wechaty/wechaty/pull/1752) ([linyimin-bupt](https://github.com/linyimin-bupt))
- add send urlLink example code [\#1750](https://github.com/wechaty/wechaty/pull/1750) ([linyimin-bupt](https://github.com/linyimin-bupt))
- fix comment error [\#1749](https://github.com/wechaty/wechaty/pull/1749) ([linyimin-bupt](https://github.com/linyimin-bupt))
- Add `Message.recalled\(\)` [\#1735](https://github.com/wechaty/wechaty/pull/1735) ([windmemory](https://github.com/windmemory))
- revise room.say\(\) mention function [\#1729](https://github.com/wechaty/wechaty/pull/1729) ([windmemory](https://github.com/windmemory))
- fix document presentation bugs [\#1713](https://github.com/wechaty/wechaty/pull/1713) ([TbhT](https://github.com/TbhT))
- code clean for issue template [\#1702](https://github.com/wechaty/wechaty/pull/1702) ([lijiarui](https://github.com/lijiarui))
- add issue template [\#1700](https://github.com/wechaty/wechaty/pull/1700) ([lijiarui](https://github.com/lijiarui))
- Change chatie org to wechaty org [\#1692](https://github.com/wechaty/wechaty/pull/1692) ([lijiarui](https://github.com/lijiarui))
- Update the Message.toString format, close \#1676 [\#1677](https://github.com/wechaty/wechaty/pull/1677) ([suntong](https://github.com/suntong))
- Fix room mention [\#1666](https://github.com/wechaty/wechaty/pull/1666) ([lhr0909](https://github.com/lhr0909))
- Pass mention list down to puppet and use mentionIdList from puppet if possible [\#1662](https://github.com/wechaty/wechaty/pull/1662) ([windmemory](https://github.com/windmemory))
- fix: Message.mention\(\) [\#1661](https://github.com/wechaty/wechaty/pull/1661) ([jzj1993](https://github.com/jzj1993))
- Adjust data sync order for message ready [\#1660](https://github.com/wechaty/wechaty/pull/1660) ([windmemory](https://github.com/windmemory))
- Upgrade wechaty-puppet-padchat version in puppet config [\#1643](https://github.com/wechaty/wechaty/pull/1643) ([windmemory](https://github.com/windmemory))
- Docs [\#1633](https://github.com/wechaty/wechaty/pull/1633) ([lijiarui](https://github.com/lijiarui))
- Docs [\#1631](https://github.com/wechaty/wechaty/pull/1631) ([lijiarui](https://github.com/lijiarui))
- new Puppet - wechaty-puppet-padpro [\#1630](https://github.com/wechaty/wechaty/pull/1630) ([windmemory](https://github.com/windmemory))
- docs: fixed typo [\#1625](https://github.com/wechaty/wechaty/pull/1625) ([Gcaufy](https://github.com/Gcaufy))
- fix typo [\#1623](https://github.com/wechaty/wechaty/pull/1623) ([kis87988](https://github.com/kis87988))
- docs: Fixed FriendshipType enum typo [\#1620](https://github.com/wechaty/wechaty/pull/1620) ([Gcaufy](https://github.com/Gcaufy))
- README typo [\#1615](https://github.com/wechaty/wechaty/pull/1615) ([lijiarui](https://github.com/lijiarui))
- Contribute [\#1614](https://github.com/wechaty/wechaty/pull/1614) ([lijiarui](https://github.com/lijiarui))
- fix: room mention contact should using roomAlias https://github.com/Chatie/wechaty/issues/1604 [\#1607](https://github.com/wechaty/wechaty/pull/1607) ([kis87988](https://github.com/kis87988))
- Greenkeeper/monorepo.babel7 7.0.1 [\#1597](https://github.com/wechaty/wechaty/pull/1597) ([huan](https://github.com/huan))
- add the methods' doc link [\#1583](https://github.com/wechaty/wechaty/pull/1583) ([TbhT](https://github.com/TbhT))
- update readme doc [\#1582](https://github.com/wechaty/wechaty/pull/1582) ([TbhT](https://github.com/TbhT))
- sync contactSelf after updating bot info [\#1577](https://github.com/wechaty/wechaty/pull/1577) ([windmemory](https://github.com/windmemory))

## [v0.22.4](https://github.com/wechaty/wechaty/tree/v0.22.4) (2018-08-29)

[Full Changelog](https://github.com/wechaty/wechaty/compare/v0.20.0...v0.22.4)

**Implemented enhancements:**

- Closing wechaty-puppet-padchat beta test [\#1572](https://github.com/wechaty/wechaty/issues/1572)
- Add API List to README [\#1566](https://github.com/wechaty/wechaty/issues/1566)
- Add support for send url rich media message  [\#718](https://github.com/wechaty/wechaty/issues/718)
- contact.stranger\(\) still returns true after adding friends between bot and user [\#293](https://github.com/wechaty/wechaty/issues/293)
- be careful about the `unofficial client` check and report \(in browser\) [\#29](https://github.com/wechaty/wechaty/issues/29)

**Fixed bugs:**

- ReadError: Database is not open \[object Promise\] - FlashStoreSync was closed when need writing [\#1433](https://github.com/wechaty/wechaty/issues/1433)
- The latest docker get `ContactGetter` error when get wechat OA message [\#974](https://github.com/wechaty/wechaty/issues/974)
- "Chromium revision is not downloaded." [\#954](https://github.com/wechaty/wechaty/issues/954)
- Room.memberAll\(FilterString\) if FilterString are all with emojis [\#704](https://github.com/wechaty/wechaty/issues/704)
- `Room.find\(\)` can find the room when the bot is removed from the room [\#254](https://github.com/wechaty/wechaty/issues/254)

**Closed issues:**

- bot logined, but `scan` event still. [\#1567](https://github.com/wechaty/wechaty/issues/1567)
- Wechaty v0.20 & Puppet Padchat v0.14 Released. Padchat Alpha Testing Closed. [\#1296](https://github.com/wechaty/wechaty/issues/1296)
- Session closed when running for a long time  [\#1052](https://github.com/wechaty/wechaty/issues/1052)

**Merged pull requests:**

- Bump wechaty-puppet-padchat version [\#1571](https://github.com/wechaty/wechaty/pull/1571) ([windmemory](https://github.com/windmemory))
- Edit room doc [\#1570](https://github.com/wechaty/wechaty/pull/1570) ([kis87988](https://github.com/kis87988))

## [v0.20.0](https://github.com/wechaty/wechaty/tree/v0.20.0) (2018-08-18)

[Full Changelog](https://github.com/wechaty/wechaty/compare/v0.18.0...v0.20.0)

**Implemented enhancements:**

- \[RFC\] Suggest to have more detailed error message when doing ContactSelf related operations [\#1549](https://github.com/wechaty/wechaty/issues/1549)
- feat: add receive and send link [\#1539](https://github.com/wechaty/wechaty/issues/1539)
- Feat: add `Message.find` to search in cache. [\#1534](https://github.com/wechaty/wechaty/issues/1534)
- Get Rid of the Dependences which requires build when `npm install` [\#1529](https://github.com/wechaty/wechaty/issues/1529)
- Puppet Padchat Not Supported Attachment File Type in Message. [\#1524](https://github.com/wechaty/wechaty/issues/1524)
- BREAKING CHANGE: v0.20 `Contact.alias` changed from Sync to Async [\#1500](https://github.com/wechaty/wechaty/issues/1500)
- Pre-install all official supported Puppets when build docker image [\#1493](https://github.com/wechaty/wechaty/issues/1493)
- 【Proposal】New 'room-invite' event [\#1492](https://github.com/wechaty/wechaty/issues/1492)
- Message type: mini program for Message.type\(\) [\#1444](https://github.com/wechaty/wechaty/issues/1444)
- Promote PuppetPadchat to SOLO NPM Module wechaty-puppet-padchat [\#1372](https://github.com/wechaty/wechaty/issues/1372)
- PuppetPadchat: support message type of `StatusNotify` with `op id` push update information [\#1310](https://github.com/wechaty/wechaty/issues/1310)
- Make tslint.json to be simple with `extends` standard. [\#1303](https://github.com/wechaty/wechaty/issues/1303)
- feat: PuppetPadchat supports get QrCode for userSelf\(can be scan by others for adding friend\) [\#1301](https://github.com/wechaty/wechaty/issues/1301)
- New Puppet: PuppetPadchat [\#1249](https://github.com/wechaty/wechaty/issues/1249)
- feat: add `Wechaty.unref\(\)` support to unref all the underlying resources. [\#1197](https://github.com/wechaty/wechaty/issues/1197)
- Disable HotImport in PRODUCTION Environment [\#907](https://github.com/wechaty/wechaty/issues/907)
- Reconstruction PuppeteerMessage Class [\#724](https://github.com/wechaty/wechaty/issues/724)
- \[New Puppet\] PuppetWechat4u - enable by `WECHATY\_PUPPET=wechat4u` [\#69](https://github.com/wechaty/wechaty/issues/69)

**Fixed bugs:**

- TypeError: Cannot read property 'type' of undefined     at AnotherOriginalClass.type  [\#1545](https://github.com/wechaty/wechaty/issues/1545)
- contact alias not sync after call contact.alias\(string\) to set alias [\#1517](https://github.com/wechaty/wechaty/issues/1517)
- Fix Puppet Memory Multiplex Problem with Multi-Instance Wechaty and Pre-Instanced Puppet [\#1516](https://github.com/wechaty/wechaty/issues/1516)
- Question: How to pre-set puppet module to be used by wechaty with docker [\#1478](https://github.com/wechaty/wechaty/issues/1478)
- JSDoc bugs [\#1475](https://github.com/wechaty/wechaty/issues/1475)
- PuppetPadChat:Contact.avatar\(\) Error [\#1473](https://github.com/wechaty/wechaty/issues/1473)
- PuppetWeb loses event listeners when resetting [\#1470](https://github.com/wechaty/wechaty/issues/1470)
- Check the puppet version to satisfy the Wechaty requirement  [\#1453](https://github.com/wechaty/wechaty/issues/1453)
- Split the `xxxIdList` to chunks when map it to payload to prevent block the event loop [\#1450](https://github.com/wechaty/wechaty/issues/1450)
- `puppetPadchat.reset\(\)` should call `start\(\)` after `stop\(\)` [\#1385](https://github.com/wechaty/wechaty/issues/1385)
-  cannot run `speech-to-text-bot` [\#1350](https://github.com/wechaty/wechaty/issues/1350)
- Error: Cannot stub non-existent own property [\#1247](https://github.com/wechaty/wechaty/issues/1247)
- How to run hot-import-bot example [\#1222](https://github.com/wechaty/wechaty/issues/1222)
- PuppetWebEvent onLogin: browser not fully loaded\(ttl=30\), retry later [\#970](https://github.com/wechaty/wechaty/issues/970)

**Closed issues:**

- appear bug when logout use padchat [\#1559](https://github.com/wechaty/wechaty/issues/1559)
- \[RFC\] Shall we clean up room information when we receive room events? [\#1552](https://github.com/wechaty/wechaty/issues/1552)
- Want to create UrlLink with control on all properties [\#1541](https://github.com/wechaty/wechaty/issues/1541)
- memory-card cannot save successfully [\#1537](https://github.com/wechaty/wechaty/issues/1537)
- Error: Cannot find module 'babel-plugin-transform-runtime' from '/bot' [\#1536](https://github.com/wechaty/wechaty/issues/1536)
- contact name not sync after call sync\(\) or restart docker \(RPC\) [\#1531](https://github.com/wechaty/wechaty/issues/1531)
- Why wechaty need express [\#1523](https://github.com/wechaty/wechaty/issues/1523)
- calling await bot.stop\(\) can't stop the bot [\#1519](https://github.com/wechaty/wechaty/issues/1519)
- @ 人没提示 [\#1504](https://github.com/wechaty/wechaty/issues/1504)
- Puppet Name use full npm name instead of alias: padchat =\> wechaty-puppet-padchat [\#1496](https://github.com/wechaty/wechaty/issues/1496)
- why friendship.contact\(\).name\(\) is "" [\#1490](https://github.com/wechaty/wechaty/issues/1490)
- why the padchat always restart\(login\)? [\#1485](https://github.com/wechaty/wechaty/issues/1485)
- sending a custom emotic led to an error on the server [\#1483](https://github.com/wechaty/wechaty/issues/1483)
- PuppetPadChat: The server always restart on pm2. [\#1472](https://github.com/wechaty/wechaty/issues/1472)
- PuppetPadchat Not response after run several hours   [\#1443](https://github.com/wechaty/wechaty/issues/1443)
- PuppetPadchat: make contact has a function with real wechat ID [\#1423](https://github.com/wechaty/wechaty/issues/1423)
- Maybe we shouldn't syncContactsAndRooms per 3 hours [\#1414](https://github.com/wechaty/wechaty/issues/1414)
- PuppetPadchat: Cannot read property 'user\_name' of undefined [\#1392](https://github.com/wechaty/wechaty/issues/1392)
- I changed my operating system，but when run dev ,still output restarting [\#1382](https://github.com/wechaty/wechaty/issues/1382)
- Room-join event show  ERR PuppetWebFirer fireRoomJoin\(\) not found\(yet\) error   \(Bug\) [\#1169](https://github.com/wechaty/wechaty/issues/1169)
- `Room.findAll\(\)` get error when rooms more than 400 [\#1112](https://github.com/wechaty/wechaty/issues/1112)
- emit error event when listen the page has been closed [\#1110](https://github.com/wechaty/wechaty/issues/1110)

**Merged pull requests:**

- sync room when receive room events [\#1557](https://github.com/wechaty/wechaty/pull/1557) ([windmemory](https://github.com/windmemory))
- better error message for contact self operations [\#1550](https://github.com/wechaty/wechaty/pull/1550) ([windmemory](https://github.com/windmemory))
- add receive and send link prototype [\#1538](https://github.com/wechaty/wechaty/pull/1538) ([windmemory](https://github.com/windmemory))
- add ready in jsdoc [\#1533](https://github.com/wechaty/wechaty/pull/1533) ([lijiarui](https://github.com/lijiarui))
- add check isMentionMe method [\#1532](https://github.com/wechaty/wechaty/pull/1532) ([bitwater](https://github.com/bitwater))
- Add method in ContactSelf to update name and signature [\#1526](https://github.com/wechaty/wechaty/pull/1526) ([windmemory](https://github.com/windmemory))
- remove useless param type in example code [\#1514](https://github.com/wechaty/wechaty/pull/1514) ([lijiarui](https://github.com/lijiarui))
- aad room invitation jsdoc [\#1510](https://github.com/wechaty/wechaty/pull/1510) ([lijiarui](https://github.com/lijiarui))
- feat: \[Prototype\] adding new data-ready event [\#1503](https://github.com/wechaty/wechaty/pull/1503) ([windmemory](https://github.com/windmemory))
- Contact get alias from sync to async [\#1502](https://github.com/wechaty/wechaty/pull/1502) ([lijiarui](https://github.com/lijiarui))
- add Contact self class [\#1498](https://github.com/wechaty/wechaty/pull/1498) ([lijiarui](https://github.com/lijiarui))
- remove a outdated file-box function [\#1497](https://github.com/wechaty/wechaty/pull/1497) ([lijiarui](https://github.com/lijiarui))
- Add api to explain which belongs to web API, which belongs to padchat API, which belongs… [\#1486](https://github.com/wechaty/wechaty/pull/1486) ([lijiarui](https://github.com/lijiarui))
- move wechaty-getting-started from lijiarui to chatie [\#1482](https://github.com/wechaty/wechaty/pull/1482) ([lijiarui](https://github.com/lijiarui))
- file\(\) desperate, use toFileBox instead [\#1481](https://github.com/wechaty/wechaty/pull/1481) ([lijiarui](https://github.com/lijiarui))
- fix \#1475 bug [\#1477](https://github.com/wechaty/wechaty/pull/1477) ([lijiarui](https://github.com/lijiarui))

## [v0.18.0](https://github.com/wechaty/wechaty/tree/v0.18.0) (2018-07-11)

[Full Changelog](https://github.com/wechaty/wechaty/compare/v0.16.0...v0.18.0)

**Implemented enhancements:**

- PuppetPadchat Upgrade TODO Lists [\#1442](https://github.com/wechaty/wechaty/issues/1442)
- Dynamic install puppet implementations instead of pre-install [\#1437](https://github.com/wechaty/wechaty/issues/1437)
- Split PuppetWechat4u as a NPM module [\#1419](https://github.com/wechaty/wechaty/issues/1419)
- PuppetPadchat: The contact.star\(\) doesn't work [\#1413](https://github.com/wechaty/wechaty/issues/1413)
- Promote PuppetPuppeteer to SOLO NPM Module wechaty-puppet-puppeteer [\#1371](https://github.com/wechaty/wechaty/issues/1371)
- Promote Puppet to SOLO NPM Module wechaty-puppet [\#1370](https://github.com/wechaty/wechaty/issues/1370)
- New Puppet: PuppetMock for Testing & Starter [\#1177](https://github.com/wechaty/wechaty/issues/1177)

**Fixed bugs:**

- Cannot detect the the environment WECHATY\_PUPPET v0.17.118  [\#1456](https://github.com/wechaty/wechaty/issues/1456)
- PuppetPadchat Server logout and login cycle average 3-5mins [\#1446](https://github.com/wechaty/wechaty/issues/1446)
- WARN PuppetPuppeteer initWatchdogForPuppet\(\) dog.on\(reset\) last food:inited, timeout:120000 [\#1439](https://github.com/wechaty/wechaty/issues/1439)
- ts-node 7.0 breaking change: Skip `files` by default [\#1383](https://github.com/wechaty/wechaty/issues/1383)
- Can not find room after add member to the room [\#1380](https://github.com/wechaty/wechaty/issues/1380)
- PuppetPadchat: `friend` value of `ContactPayload` is undefined [\#1359](https://github.com/wechaty/wechaty/issues/1359)
- WXGetContact cannot get user\_name [\#1358](https://github.com/wechaty/wechaty/issues/1358)
- leveldown::Database::Close: Program terminated with signal SIGSEGV, Segmentation fault. [\#1355](https://github.com/wechaty/wechaty/issues/1355)

**Closed issues:**

- QR Code problem under screen/xterm [\#1455](https://github.com/wechaty/wechaty/issues/1455)
- How to get the room title in v0.17 wechaty? [\#1454](https://github.com/wechaty/wechaty/issues/1454)
- should not download chromium by default [\#1451](https://github.com/wechaty/wechaty/issues/1451)
- PuppetPadChat:Send media file. [\#1436](https://github.com/wechaty/wechaty/issues/1436)
- PuppetPadchat:My wechat accou can not login. [\#1416](https://github.com/wechaty/wechaty/issues/1416)
- It reports errors when the room delete one member. [\#1415](https://github.com/wechaty/wechaty/issues/1415)
- `cannot get user\_name from raw payload: {} \[object Promise\]` Error [\#1399](https://github.com/wechaty/wechaty/issues/1399)
- Where can I see the complete API documentation of puppet-padchat, such as createRoom and Moment [\#1391](https://github.com/wechaty/wechaty/issues/1391)
- still restart [\#1378](https://github.com/wechaty/wechaty/issues/1378)
- WARN PuppetPuppeteer [\#1376](https://github.com/wechaty/wechaty/issues/1376)
- m.say\(\) repeat many many times [\#1216](https://github.com/wechaty/wechaty/issues/1216)
- room.say mention is not work [\#1185](https://github.com/wechaty/wechaty/issues/1185)
- 获取所有群 [\#1020](https://github.com/wechaty/wechaty/issues/1020)
- Any way to keep login for days? [\#988](https://github.com/wechaty/wechaty/issues/988)

**Merged pull requests:**

- update version of puppet-padchat [\#1457](https://github.com/wechaty/wechaty/pull/1457) ([windmemory](https://github.com/windmemory))
- catch error when get undifined user\_name in room [\#1408](https://github.com/wechaty/wechaty/pull/1408) ([lijiarui](https://github.com/lijiarui))
- add a more suitable time to sync Contact and Room [\#1407](https://github.com/wechaty/wechaty/pull/1407) ([lijiarui](https://github.com/lijiarui))
- mock self bot when WXGetContact\(\) return null user\_name [\#1405](https://github.com/wechaty/wechaty/pull/1405) ([lijiarui](https://github.com/lijiarui))
- sync contact and room per hour [\#1402](https://github.com/wechaty/wechaty/pull/1402) ([lijiarui](https://github.com/lijiarui))

## [v0.16.0](https://github.com/wechaty/wechaty/tree/v0.16.0) (2018-06-21)

[Full Changelog](https://github.com/wechaty/wechaty/compare/v0.14.0...v0.16.0)

**Implemented enhancements:**

- Unable to start multiple instances with padchat puppet [\#1367](https://github.com/wechaty/wechaty/issues/1367)
- Prevent the Floating Promise in the Async/Await Code [\#1346](https://github.com/wechaty/wechaty/issues/1346)
- BREAKING CHANGES v0.16: FriendRequest class will be replaced with Friendship [\#1312](https://github.com/wechaty/wechaty/issues/1312)
- feat: PuppetPadchat can set avatar for userself support. [\#1298](https://github.com/wechaty/wechaty/issues/1298)
- BREAKING CHANGE: v0.16 `Room.topic\(\)` change from Sycn to Async [\#1295](https://github.com/wechaty/wechaty/issues/1295)
- BREAKING CHANGE: v0.16 `Room.alias\(contact\)` change from Sycn to Async [\#1293](https://github.com/wechaty/wechaty/issues/1293)
- BREAKING CHANGE: v0.16 `Room.memberList\(\)` change from Sycn to Async [\#1290](https://github.com/wechaty/wechaty/issues/1290)
- BREAKING CHANGE: v0.16 `Room.has\(contact\)` change from Sycn to Async [\#1289](https://github.com/wechaty/wechaty/issues/1289)
- BREAKING CHANGE: v0.16 `scan` event args will be different! [\#1262](https://github.com/wechaty/wechaty/issues/1262)
- BREAKING CHANGE: v0.16 `Message.mention\(\)` change from `sync` to `async` [\#1259](https://github.com/wechaty/wechaty/issues/1259)
- BREAKING CHANGES: v0.16 `Room.member\(\)` from `sync` to `async` [\#1258](https://github.com/wechaty/wechaty/issues/1258)
- Promote `Profile` class to a solo NPM module: `MemoryCard` [\#1257](https://github.com/wechaty/wechaty/issues/1257)
- rewrite roomFindAll\(\)  [\#1255](https://github.com/wechaty/wechaty/issues/1255)
- function friendRequestAccept [\#1254](https://github.com/wechaty/wechaty/issues/1254)
-  read messageRawPayload by id [\#1253](https://github.com/wechaty/wechaty/issues/1253)
- function friendRequestSend [\#1252](https://github.com/wechaty/wechaty/issues/1252)
- rewrite contactFindAll\(\) [\#1251](https://github.com/wechaty/wechaty/issues/1251)
- Upgrade Docker Base Image from Ubuntu 17.10 to 18.04 [\#1239](https://github.com/wechaty/wechaty/issues/1239)
- NPM Switch: `promise-retry` to replace `retry-promise` [\#1235](https://github.com/wechaty/wechaty/issues/1235)
- Add unit test to puppet accessory [\#1219](https://github.com/wechaty/wechaty/issues/1219)
- Use browser implementation of Node.js' stream library [\#1201](https://github.com/wechaty/wechaty/issues/1201)
- feat: Add `for await \(const contact of room\) {}` support by ES6 iterators override [\#1198](https://github.com/wechaty/wechaty/issues/1198)
- BREAKING CHANGE: v0.16 on\('friend`\) arguments changed! [\#1196](https://github.com/wechaty/wechaty/issues/1196)
- TypeScript Strict Mode: set `noImplicitAny` to `true` [\#1180](https://github.com/wechaty/wechaty/issues/1180)
- Generic for Return Child Class Type in Abstract Class Implementation [\#1178](https://github.com/wechaty/wechaty/issues/1178)
- BREAKING CHANGE: v0.16 Message.ext\(\) return '.ext' instead of 'ext' before [\#1168](https://github.com/wechaty/wechaty/issues/1168)
- Encapsulated `Contact`, `Messag`, `FriendRequest`, and `Room` into `PuppetWeb` [\#1166](https://github.com/wechaty/wechaty/issues/1166)
- BREAKING CHANGE: v0.16 will remove `MediaMessage` class [\#1164](https://github.com/wechaty/wechaty/issues/1164)
- BREAKING CHANGE: v0.16 will replace `Message.content\(\)` with `Message.text\(\)` [\#1163](https://github.com/wechaty/wechaty/issues/1163)
- Continious Deploy to NPM with @next tag when the MINOR version number is odd\(in developing branch\) [\#1158](https://github.com/wechaty/wechaty/issues/1158)
- BREAKING CHANGE: first arg of `room-leave` event licener changed from `Contact` to `Contact\[\]` [\#723](https://github.com/wechaty/wechaty/issues/723)
- Should throw Exception when there have API Error. [\#683](https://github.com/wechaty/wechaty/issues/683)
- delay time for all function\(method\) that calls Tencent API [\#596](https://github.com/wechaty/wechaty/issues/596)
- \[todo\] allow Wechaty to be multi-instance [\#518](https://github.com/wechaty/wechaty/issues/518)

**Fixed bugs:**

- When bot quit the room, bot still thought it in the room. [\#1345](https://github.com/wechaty/wechaty/issues/1345)
- When the bot remove one out of the group, room data didn't refresh [\#1343](https://github.com/wechaty/wechaty/issues/1343)
- Room Event cannot work as expect after create a new room [\#1342](https://github.com/wechaty/wechaty/issues/1342)
- cannot refresh room data when execute the code again [\#1339](https://github.com/wechaty/wechaty/issues/1339)
- can't run demo [\#1337](https://github.com/wechaty/wechaty/issues/1337)
- room-leave error [\#1334](https://github.com/wechaty/wechaty/issues/1334)
- room-join event, when run `room.say`, it actually run `contact.say` [\#1330](https://github.com/wechaty/wechaty/issues/1330)
- room-leave event cannot get leaver member [\#1329](https://github.com/wechaty/wechaty/issues/1329)
- should refresh room data when there is a room event [\#1328](https://github.com/wechaty/wechaty/issues/1328)
- \[room topic event\]  throw error: no changerId found [\#1326](https://github.com/wechaty/wechaty/issues/1326)
- room-join cannot get member [\#1324](https://github.com/wechaty/wechaty/issues/1324)
- `contact.avatar\(\)` cannot work as expect [\#1321](https://github.com/wechaty/wechaty/issues/1321)
- run contact-bot throw error [\#1319](https://github.com/wechaty/wechaty/issues/1319)
- Padchat: WXAutoLogin result is faild, but I still receive message [\#1316](https://github.com/wechaty/wechaty/issues/1316)
- Fix the `+` in data for PuppetPadchat [\#1302](https://github.com/wechaty/wechaty/issues/1302)
- get fromId not right for room invitation sys message [\#1297](https://github.com/wechaty/wechaty/issues/1297)
- Error: The command "echo $TRAVIS\_OS\_NAME" exited with 1. [\#1236](https://github.com/wechaty/wechaty/issues/1236)
- TravisCI Conditional Deployment [\#1211](https://github.com/wechaty/wechaty/issues/1211)
- Update the peerDependencies of `rx-queue`: rxjs@6 from rxjs@5 [\#1205](https://github.com/wechaty/wechaty/issues/1205)
- Cannot send image message on v0.15.21 [\#1175](https://github.com/wechaty/wechaty/issues/1175)
- cannot refresh room topic or contact name [\#1157](https://github.com/wechaty/wechaty/issues/1157)
- How to avoid the memory leak [\#981](https://github.com/wechaty/wechaty/issues/981)
- Puppeteer Navigation Timeout Exceeded: 30000ms exceeded [\#870](https://github.com/wechaty/wechaty/issues/870)
- SyntaxError: Unexpected end of JSON input [\#846](https://github.com/wechaty/wechaty/issues/846)
- function `Message.mention\(\)` should recognize both magic code and blank [\#813](https://github.com/wechaty/wechaty/issues/813)

**Closed issues:**

- BREAKING CHANGE v0.16 Wechaty.self\(\) eprecated, use Wechaty.userSelf\(\)  instead [\#1369](https://github.com/wechaty/wechaty/issues/1369)
- BREAKING CHANGE v0.16 Contact.personal\(\) and Contact.official\(\)  deprecated, use Contact.type\(\) instead [\#1366](https://github.com/wechaty/wechaty/issues/1366)
-  no encodedText error in `padchat-decode.ts` [\#1365](https://github.com/wechaty/wechaty/issues/1365)
- BREAKING CHANGE v0.16  room.add return Promise\<void\> instead of return Promise\<boolean\> [\#1362](https://github.com/wechaty/wechaty/issues/1362)
- `media-file-bot` cannot save xlsx file [\#1349](https://github.com/wechaty/wechaty/issues/1349)
- room-leave-error [\#1335](https://github.com/wechaty/wechaty/issues/1335)
- room-leave event throw error, cannot get leaver contact [\#1323](https://github.com/wechaty/wechaty/issues/1323)
- `friendship`  cannot accept friend request automatically [\#1322](https://github.com/wechaty/wechaty/issues/1322)
- PadchatRpc WXCheckQRCode result: {"message":"WS请求错误","status":-19} [\#1315](https://github.com/wechaty/wechaty/issues/1315)
- m.forward 是 undefined ？ [\#1272](https://github.com/wechaty/wechaty/issues/1272)
- Navigation Timeout Exceeded: 30000ms exceeded [\#1248](https://github.com/wechaty/wechaty/issues/1248)
- profile.set can only set 'cookies' instead of other keys [\#1240](https://github.com/wechaty/wechaty/issues/1240)
- Create a websocket ipad demo [\#1228](https://github.com/wechaty/wechaty/issues/1228)
- Proper wechaty and its dependency installation [\#1225](https://github.com/wechaty/wechaty/issues/1225)
- can't run the typescript examples [\#1221](https://github.com/wechaty/wechaty/issues/1221)
- Scan QR Code not shown on terminal, wechaty@0.14.4 [\#1220](https://github.com/wechaty/wechaty/issues/1220)
- 请问怎么添加微信群中的人当做自己的好友呢 有例子可以参考吗 [\#1207](https://github.com/wechaty/wechaty/issues/1207)
- room-bot.ts error [\#1199](https://github.com/wechaty/wechaty/issues/1199)
- TypeScript 2.9 with trailing comma after rest parameters. [\#1188](https://github.com/wechaty/wechaty/issues/1188)
- code example 'media-file-bot' not working [\#1183](https://github.com/wechaty/wechaty/issues/1183)
- QrCode `scan` event not refresh on v0.15.21 \#1175 [\#1176](https://github.com/wechaty/wechaty/issues/1176)
- Version 10 of node.js has been released [\#1170](https://github.com/wechaty/wechaty/issues/1170)
- 自动加好友，加好友成功后，向对方发信息报错 [\#1165](https://github.com/wechaty/wechaty/issues/1165)
- Use `injection-js` for Wechaty v1.0 provide the resolvers of the Wechaty Puppet [\#1146](https://github.com/wechaty/wechaty/issues/1146)
- findAll ,WARN Room parse\(\) on a empty rawObj [\#1141](https://github.com/wechaty/wechaty/issues/1141)
- Rename all `find\(\)` method to `search\(\)` [\#1132](https://github.com/wechaty/wechaty/issues/1132)
- ERR PuppetWebBridge init\(\) exception: Error: connect ECONNREFUSED 127.0.0.1:35493 [\#1113](https://github.com/wechaty/wechaty/issues/1113)
- Feature request: sending file with a stream \(creating media message with a stream\) [\#1092](https://github.com/wechaty/wechaty/issues/1092)
- node\_modules/\_wechaty@0.13.36@wechaty/dist/src/config.d.ts\(1,24\): error TS2307: Cannot find module 'raven'. [\#1035](https://github.com/wechaty/wechaty/issues/1035)

**Merged pull requests:**

- add await for promise [\#1375](https://github.com/wechaty/wechaty/pull/1375) ([lijiarui](https://github.com/lijiarui))
- Fix room.add\(\) failed when room member more than 40 [\#1374](https://github.com/wechaty/wechaty/pull/1374) ([lijiarui](https://github.com/lijiarui))
- call randam server for stable [\#1373](https://github.com/wechaty/wechaty/pull/1373) ([lijiarui](https://github.com/lijiarui))
- check room valid by id [\#1352](https://github.com/wechaty/wechaty/pull/1352) ([lijiarui](https://github.com/lijiarui))
- fixed cannot find room by topic after bot create room [\#1351](https://github.com/wechaty/wechaty/pull/1351) ([lijiarui](https://github.com/lijiarui))
- fix warnings when run `npm run lint` [\#1348](https://github.com/wechaty/wechaty/pull/1348) ([lijiarui](https://github.com/lijiarui))
- test `room.quit\(\)` in room-bot [\#1347](https://github.com/wechaty/wechaty/pull/1347) ([lijiarui](https://github.com/lijiarui))
- add log as \#1342 [\#1344](https://github.com/wechaty/wechaty/pull/1344) ([lijiarui](https://github.com/lijiarui))
- Bug compatible WXCreateChatRoom [\#1341](https://github.com/wechaty/wechaty/pull/1341) ([lijiarui](https://github.com/lijiarui))
- add room-bot test code [\#1338](https://github.com/wechaty/wechaty/pull/1338) ([lijiarui](https://github.com/lijiarui))
- save room join sys message to cache [\#1333](https://github.com/wechaty/wechaty/pull/1333) ([lijiarui](https://github.com/lijiarui))
- add function in self-testing-bot.ts [\#1331](https://github.com/wechaty/wechaty/pull/1331) ([lijiarui](https://github.com/lijiarui))
- Room bot example [\#1325](https://github.com/wechaty/wechaty/pull/1325) ([lijiarui](https://github.com/lijiarui))

## [v0.14.0](https://github.com/wechaty/wechaty/tree/v0.14.0) (2018-04-15)

[Full Changelog](https://github.com/wechaty/wechaty/compare/v0.12.0...v0.14.0)

**Implemented enhancements:**

- Rename {test,fixture,example,...} to {tests,fixtures,examples,...} etc. [\#1127](https://github.com/wechaty/wechaty/issues/1127)
- Trigger Deploy on Branch /v\d+\.\d+\$/ [\#956](https://github.com/wechaty/wechaty/issues/956)
- Wechaty Version Numbering [\#905](https://github.com/wechaty/wechaty/issues/905)
- \[New Puppet\] Puppeteer [\#790](https://github.com/wechaty/wechaty/issues/790)
- \[enhancement\] Add timezone in to Dockerfile [\#594](https://github.com/wechaty/wechaty/issues/594)
- \[docker\] to prevent docker users install a local dependence of wechaty [\#281](https://github.com/wechaty/wechaty/issues/281)

**Fixed bugs:**

- When run CI inside the container: openBinaryFile: does not exist \(No such file or directory\) [\#1137](https://github.com/wechaty/wechaty/issues/1137)
- Try to use ~~Wercker~~ Shippable CI to replace Circle CI [\#1134](https://github.com/wechaty/wechaty/issues/1134)
- Pupeteer not work after upgrade to v1.1 [\#1103](https://github.com/wechaty/wechaty/issues/1103)
- 关于MsgType 的介绍文档404了 [\#1079](https://github.com/wechaty/wechaty/issues/1079)
- Docker test fail because ts-node behavior changed between v3 and v4 [\#1050](https://github.com/wechaty/wechaty/issues/1050)
- fix description [\#1027](https://github.com/wechaty/wechaty/issues/1027)
- ERR Profile save\(\) exception: Error: EACCES: permission denied, open '/bot/demo.wechaty.json' [\#982](https://github.com/wechaty/wechaty/issues/982)
- Dockerfile.onbuild build error.Directory permissions wrong [\#961](https://github.com/wechaty/wechaty/issues/961)
- \[docker\] onbuild failed to start when we put `wechaty` as dependency in package.json [\#500](https://github.com/wechaty/wechaty/issues/500)

**Closed issues:**

- How to send file [\#1150](https://github.com/wechaty/wechaty/issues/1150)
- Signals \(e.g. ^C\) handling [\#1122](https://github.com/wechaty/wechaty/issues/1122)
- OK to add a .eslintrc.js file? [\#1120](https://github.com/wechaty/wechaty/issues/1120)
- Q: All the media types [\#1115](https://github.com/wechaty/wechaty/issues/1115)
- `TTL expired` error when login [\#1114](https://github.com/wechaty/wechaty/issues/1114)
-  `Cannot read property 'MemberList' of undefined ` still exisit in the latest docker version [\#1111](https://github.com/wechaty/wechaty/issues/1111)
- emoji suggestion [\#1108](https://github.com/wechaty/wechaty/issues/1108)
- Regenerate docs/index.md by run `npm run doc` [\#1105](https://github.com/wechaty/wechaty/issues/1105)
- hot-reload-bot adding hot-reloading config [\#1100](https://github.com/wechaty/wechaty/issues/1100)
- Third options to run wechaty [\#1085](https://github.com/wechaty/wechaty/issues/1085)
- issue [\#1076](https://github.com/wechaty/wechaty/issues/1076)
- Session last only for 1 hour in Azure [\#1059](https://github.com/wechaty/wechaty/issues/1059)
- 出现 no Url 错误后，程序崩溃 [\#1055](https://github.com/wechaty/wechaty/issues/1055)
- 图片发送一次后,图片损坏 [\#1040](https://github.com/wechaty/wechaty/issues/1040)
-  ERR PuppetWebBridge init\(\) exception [\#1018](https://github.com/wechaty/wechaty/issues/1018)
- 我实在解决不了这个问题了~菜鸟一枚 [\#998](https://github.com/wechaty/wechaty/issues/998)
- TypeError: Cannot read property 'MemberList' of undefined [\#984](https://github.com/wechaty/wechaty/issues/984)
- Using hot-import cannot quit wechaty when quit the code [\#978](https://github.com/wechaty/wechaty/issues/978)
- Error: Navigation Timeout Exceeded: 30000ms exceeded [\#966](https://github.com/wechaty/wechaty/issues/966)
- hot-reload does not work [\#958](https://github.com/wechaty/wechaty/issues/958)
- \[docker\] Login error [\#950](https://github.com/wechaty/wechaty/issues/950)
-  Invalid audio output parameters received; using fake audio path.   [\#939](https://github.com/wechaty/wechaty/issues/939)
- Keep getting "can not found bot file: src/main.ts" [\#937](https://github.com/wechaty/wechaty/issues/937)
- glSetDrawRectangleCHROMIUM: failed on surface [\#934](https://github.com/wechaty/wechaty/issues/934)
- \[FR\] Create an example for using hot-import for listener and other modules [\#923](https://github.com/wechaty/wechaty/issues/923)
- Bot log out frequently and got some strange error between it logout and relogin automatically [\#612](https://github.com/wechaty/wechaty/issues/612)

**Merged pull requests:**

- chore\(package\): update ws to version 5.1.0 [\#1143](https://github.com/wechaty/wechaty/pull/1143) ([huan](https://github.com/huan))
- chore\(package\): update puppeteer to version 1.2.0 [\#1131](https://github.com/wechaty/wechaty/pull/1131) ([huan](https://github.com/huan))
- - \[+\] add one more test case for digestEmoji\(\), close \#1108 [\#1129](https://github.com/wechaty/wechaty/pull/1129) ([suntong](https://github.com/suntong))
- hot-reload-bot adding hot-reloading config close \#1066, close \#1100 [\#1123](https://github.com/wechaty/wechaty/pull/1123) ([suntong](https://github.com/suntong))
- cannot recognize room event [\#1116](https://github.com/wechaty/wechaty/pull/1116) ([lijiarui](https://github.com/lijiarui))
- fix chown: invalid user: ‘bot’ [\#1089](https://github.com/wechaty/wechaty/pull/1089) ([mukaiu](https://github.com/mukaiu))
- Add troubleshooting for hidden .txt files \(Windows\) [\#1087](https://github.com/wechaty/wechaty/pull/1087) ([IdiosApps](https://github.com/IdiosApps))
- fix \#1079 [\#1086](https://github.com/wechaty/wechaty/pull/1086) ([lijiarui](https://github.com/lijiarui))
- chore\(package\): update @types/node to version 9.4.0 [\#1083](https://github.com/wechaty/wechaty/pull/1083) ([huan](https://github.com/huan))
- chore\(package\): update finis to version 0.4.1 [\#1075](https://github.com/wechaty/wechaty/pull/1075) ([huan](https://github.com/huan))
- chore\(package\): update ts-node to version 4.1.0 [\#1074](https://github.com/wechaty/wechaty/pull/1074) ([huan](https://github.com/huan))
- chore\(package\): update mime to version 2.2.0 [\#1073](https://github.com/wechaty/wechaty/pull/1073) ([huan](https://github.com/huan))
- chore\(package\): update tslint to version 5.9.0 [\#1072](https://github.com/wechaty/wechaty/pull/1072) ([huan](https://github.com/huan))
- chore\(package\): update sinon to version 4.2.0 [\#1071](https://github.com/wechaty/wechaty/pull/1071) ([huan](https://github.com/huan))
- fail to install node dependencies [\#1036](https://github.com/wechaty/wechaty/pull/1036) ([hiwanz](https://github.com/hiwanz))
- Change `init` to `start` in demo [\#1017](https://github.com/wechaty/wechaty/pull/1017) ([xinbenlv](https://github.com/xinbenlv))
- Update tuling123-bot.ts [\#1014](https://github.com/wechaty/wechaty/pull/1014) ([htoooth](https://github.com/htoooth))
- Fix \#923 [\#935](https://github.com/wechaty/wechaty/pull/935) ([xinbenlv](https://github.com/xinbenlv))

## [v0.12.0](https://github.com/wechaty/wechaty/tree/v0.12.0) (2017-10-30)

[Full Changelog](https://github.com/wechaty/wechaty/compare/v0.9.0...v0.12.0)

**Implemented enhancements:**

- Promote `rx-queue` to SOLO NPM Module [\#938](https://github.com/wechaty/wechaty/issues/938)
- Add Wechaty.logonoff\(\) method [\#926](https://github.com/wechaty/wechaty/issues/926)
- Registe Wechaty Listeners with a try {} catch {} block in order to prevent listener function crash the framework. [\#878](https://github.com/wechaty/wechaty/issues/878)
- Upgrade CircleCI from 1.0 to 2.0 [\#863](https://github.com/wechaty/wechaty/issues/863)
- Switch Docker Node Image from `alphin` to official `node:7` [\#862](https://github.com/wechaty/wechaty/issues/862)
- Click Web Wechat `Switch Account` Automatically to get qrcode immediately when bot logout [\#636](https://github.com/wechaty/wechaty/issues/636)
- Upgrade docker image from Node.js v7 to v8 [\#577](https://github.com/wechaty/wechaty/issues/577)
- \[todo\] switch unit test tool from AVA to TAPE [\#513](https://github.com/wechaty/wechaty/issues/513)

**Fixed bugs:**

- \[CI\] Homebrew must be run under Ruby 2.3! You're running 2.0.0. \(RuntimeError\) [\#936](https://github.com/wechaty/wechaty/issues/936)
- "PromiseRejectionHandledWarning: Promise rejection was handled asynchronously" when Wechat says "当前登录环境异常" [\#925](https://github.com/wechaty/wechaty/issues/925)
- TypeError: cookieList.filter is not a function [\#919](https://github.com/wechaty/wechaty/issues/919)
- TypeError: Cannot read property 'error' of null [\#918](https://github.com/wechaty/wechaty/issues/918)
- ERR PuppetWebBridge init\(\) initPage\(\) onLoad\(\) exception: undefined [\#917](https://github.com/wechaty/wechaty/issues/917)
- Sometimes Wechaty can't login \(with puppeteer\) [\#899](https://github.com/wechaty/wechaty/issues/899)
- \[ci\] WebDriver Error: "no such session" [\#756](https://github.com/wechaty/wechaty/issues/756)
- \[ci\] execute proxyWechaty\(init\) error: 503, init\(\) without a ready angular env [\#329](https://github.com/wechaty/wechaty/issues/329)
- \[ci log\] watchdog reset after 120 seconds [\#195](https://github.com/wechaty/wechaty/issues/195)
- Selenium WebDriver driver.getSession\(\) wait a long time [\#86](https://github.com/wechaty/wechaty/issues/86)

**Closed issues:**

- 在登录失败时的异常提示优化 [\#898](https://github.com/wechaty/wechaty/issues/898)
- CANT RUN THE WECHATY-GETTING-STARTED, PUPPETWEBROWSER valid\(\) getSession\(\) [\#891](https://github.com/wechaty/wechaty/issues/891)
- Error after restart  vps              invalid driver at ttl 0 [\#788](https://github.com/wechaty/wechaty/issues/788)
- webdriver.executeScript wait a long time\(26s\) before page load [\#2](https://github.com/wechaty/wechaty/issues/2)

**Merged pull requests:**

- Replace WebDriver by Puppeteer \(\#790\) [\#860](https://github.com/wechaty/wechaty/pull/860) ([huan](https://github.com/huan))
- chore\(package\): update coveralls to version 3.0.0 [\#854](https://github.com/wechaty/wechaty/pull/854) ([huan](https://github.com/huan))

## [v0.9.0](https://github.com/wechaty/wechaty/tree/v0.9.0) (2017-10-04)

[Full Changelog](https://github.com/wechaty/wechaty/compare/v0.8.2...v0.9.0)

**Implemented enhancements:**

- Support hot-reload for Wechaty events listeners [\#820](https://github.com/wechaty/wechaty/issues/820)
- \[jsdoc\] additional optimizations [\#774](https://github.com/wechaty/wechaty/issues/774)
- \[bug\] Support for send 25Mb+ size files [\#766](https://github.com/wechaty/wechaty/issues/766)
- \[Announcement\] Drop support for phantomjs [\#763](https://github.com/wechaty/wechaty/issues/763)
- chrome-headless support [\#739](https://github.com/wechaty/wechaty/issues/739)
- Add Transpond Message [\#726](https://github.com/wechaty/wechaty/issues/726)
- Cannot send pdf file using MediaMessage [\#710](https://github.com/wechaty/wechaty/issues/710)
- Use Sentry.io to report exceptions [\#580](https://github.com/wechaty/wechaty/issues/580)
- \[enhancement\] Add pdf, docx etc support to MediaMessage\(now only picture is supported\) [\#538](https://github.com/wechaty/wechaty/issues/538)
- use babel-node to run javascript\(.js\) file inside docker [\#507](https://github.com/wechaty/wechaty/issues/507)
- \[todo\] Change to use native Dom Websocket instead of socket.io library [\#502](https://github.com/wechaty/wechaty/issues/502)
- License Change: from ISC to Apache-2.0 [\#474](https://github.com/wechaty/wechaty/issues/474)
- requesting a new QR code cost more than 2 minutes [\#434](https://github.com/wechaty/wechaty/issues/434)
- Send\(upload\) an image twice will cause error. [\#422](https://github.com/wechaty/wechaty/issues/422)
- Keep emoji characters from user name and room name [\#207](https://github.com/wechaty/wechaty/issues/207)
- \[Feature request\] Sending Stickers [\#156](https://github.com/wechaty/wechaty/issues/156)
- \[Feature request\] @mention support? [\#153](https://github.com/wechaty/wechaty/issues/153)
- \[Docker\] add a `onbuild` image to Wechaty [\#147](https://github.com/wechaty/wechaty/issues/147)
- \[doc\] To Embed Document in Wechaty Code for Generating Automaticly [\#73](https://github.com/wechaty/wechaty/issues/73)
- it seems RECALLED: 10002 message dose't trigger on\('message'\) event [\#8](https://github.com/wechaty/wechaty/issues/8)
- Support Message Type of Image/Video  [\#4](https://github.com/wechaty/wechaty/issues/4)

**Fixed bugs:**

- Cannot send image after restart [\#777](https://github.com/wechaty/wechaty/issues/777)
- \[bug\]Cannot read property 'getUserName' of undefined [\#772](https://github.com/wechaty/wechaty/issues/772)
- \[tslint\] stuck on v5.3 and can not upgrade [\#762](https://github.com/wechaty/wechaty/issues/762)
- CI, green keeper and package-lock under npm 5 [\#656](https://github.com/wechaty/wechaty/issues/656)
- watchDogReset\(\) watchdog reset after 60 seconds \(phantomjs head\) [\#633](https://github.com/wechaty/wechaty/issues/633)
- \[test\] Unit Test for `mentioned` feature does not run at all [\#623](https://github.com/wechaty/wechaty/issues/623)
- error TS2345: Argument of type 'string | MemberQueryFilter' is not assignable to parameter of type 'MemberQueryFilter' [\#622](https://github.com/wechaty/wechaty/issues/622)
- \[Doc\] Add `say\(new MediaMessage\('/tmp/mediafile.gif'\)\)` documentation [\#587](https://github.com/wechaty/wechaty/issues/587)
- Node Typing BUG: `process.env: any` [\#582](https://github.com/wechaty/wechaty/issues/582)
- \[ci\] Appveyor error: `should get cookies after loadSession\(\)` [\#579](https://github.com/wechaty/wechaty/issues/579)
- wechaty v0.8.54 does not install all required component  [\#522](https://github.com/wechaty/wechaty/issues/522)
- message.mentioned\(\) does not work as expected [\#512](https://github.com/wechaty/wechaty/issues/512)
- Some types of media file is saved as a 0 byte file. [\#504](https://github.com/wechaty/wechaty/issues/504)
- ts-node commond not found  after update docker image [\#492](https://github.com/wechaty/wechaty/issues/492)
- may be not need .vscode folder, need .editorconfig [\#489](https://github.com/wechaty/wechaty/issues/489)
- `Room.findAll\(\)` should always return a `ready\(\)`-ed instance [\#477](https://github.com/wechaty/wechaty/issues/477)
- MediaMessage\#filename\(\) should not use timestamp as part of the filename [\#465](https://github.com/wechaty/wechaty/issues/465)
- \[ci\]   × src » message » ready\(\) contact ready for ToNickName [\#445](https://github.com/wechaty/wechaty/issues/445)
- Build Docker image from zixia/wechaty:onbuild,/bot/node\_modules does not exist. [\#436](https://github.com/wechaty/wechaty/issues/436)
- Concat.avatar\(\)  faild ,when hostname changed from https://wx.qq.com to https://wx2.qq.com [\#418](https://github.com/wechaty/wechaty/issues/418)
- \[test\] Unit Tests under Linux by TravisCI keep failing [\#384](https://github.com/wechaty/wechaty/issues/384)
- `checkRoomJoin\(\)` cannot get inviteeList sometimes [\#248](https://github.com/wechaty/wechaty/issues/248)
- \[ci log\] no driver process after quit   [\#210](https://github.com/wechaty/wechaty/issues/210)
- \[ci\] no new tests completed within the last 180000ms of inactivity [\#175](https://github.com/wechaty/wechaty/issues/175)
- how to NOT scan the QRCode on each opening [\#151](https://github.com/wechaty/wechaty/issues/151)
- Unhandled Rejection: checkLegacyResponse\(\) at error.js:505 [\#122](https://github.com/wechaty/wechaty/issues/122)
- WebDriverError: unknown error: r.isBrandContact is not a function [\#81](https://github.com/wechaty/wechaty/issues/81)
- Can't get wechaty up and running using phantomjs [\#60](https://github.com/wechaty/wechaty/issues/60)
- `accountFactory` of angularjs in wxapp work not right under Phantomjs, but it work without problem with chrome [\#28](https://github.com/wechaty/wechaty/issues/28)
- Fixed: replace `document.domain`  with `location.hostname` since front one sometimes lose subdomain name [\#770](https://github.com/wechaty/wechaty/pull/770) ([zhenyong](https://github.com/zhenyong))

**Closed issues:**

- vscode setting config error [\#843](https://github.com/wechaty/wechaty/issues/843)
- add static method `Message.findAll\(\)` [\#765](https://github.com/wechaty/wechaty/issues/765)
- cannot find Chrome binary [\#746](https://github.com/wechaty/wechaty/issues/746)
- UnhandledPromiseRejectionWarning: Unhandled promise rejection \(rejection id: 2\): Error: no puppet instance [\#738](https://github.com/wechaty/wechaty/issues/738)
- MediaMessage.filename\(\) cannot get correct img name. [\#722](https://github.com/wechaty/wechaty/issues/722)
- MediaMessage.ext\(\) cannot work as expect [\#721](https://github.com/wechaty/wechaty/issues/721)
- the latest docker version 139 cannot send file [\#720](https://github.com/wechaty/wechaty/issues/720)
- what I need is just a lib instead of a product [\#709](https://github.com/wechaty/wechaty/issues/709)
- How to link it with personal account.  [\#693](https://github.com/wechaty/wechaty/issues/693)
- Sending Images [\#690](https://github.com/wechaty/wechaty/issues/690)
- windows 10 throws PuppetWeb initBrowser\(\) exception: got invalid driver at ttl 0 [\#688](https://github.com/wechaty/wechaty/issues/688)
- Group game [\#675](https://github.com/wechaty/wechaty/issues/675)
- if wechaty cannot get inviteeList when emit `room-join` , suggest it emit room-fire and get warning info. [\#671](https://github.com/wechaty/wechaty/issues/671)
- 在 websocket 的回调中无法使用 wechaty 吗 [\#665](https://github.com/wechaty/wechaty/issues/665)
- Room.find\(\) 发送消息提示 say is not a function [\#664](https://github.com/wechaty/wechaty/issues/664)
- 获取不到avatar [\#645](https://github.com/wechaty/wechaty/issues/645)
- Get ECONNREFUSED when bot logout and cannot re-login [\#617](https://github.com/wechaty/wechaty/issues/617)
- Modify Function `Room.create` return type, from `Promise\<Room\>` to `Promise\<Room|null\>`  [\#616](https://github.com/wechaty/wechaty/issues/616)
- init 后会打开扫码的网页？ [\#601](https://github.com/wechaty/wechaty/issues/601)
- Error: ENOENT: no such file or directory, stat '/wechaty/dist/.git' [\#581](https://github.com/wechaty/wechaty/issues/581)
- 在 Windows Server 上初始化的时候，chromedriver 报错。 [\#574](https://github.com/wechaty/wechaty/issues/574)
- 启动后卡住问题 [\#566](https://github.com/wechaty/wechaty/issues/566)
- whatever [\#543](https://github.com/wechaty/wechaty/issues/543)
- \[enhancement\] handle room name change event [\#532](https://github.com/wechaty/wechaty/issues/532)
- got \[aq.qq.com\] domain [\#526](https://github.com/wechaty/wechaty/issues/526)
- some strange session error [\#523](https://github.com/wechaty/wechaty/issues/523)
- static Contact.find\(\) / static Contact.findAll\(\) throws exception [\#520](https://github.com/wechaty/wechaty/issues/520)
- Cannot set alias of Contact Object getting from `message.from\(\)` method when Contact is not a friend [\#509](https://github.com/wechaty/wechaty/issues/509)
- room.member\(\) can not return right result [\#437](https://github.com/wechaty/wechaty/issues/437)
- windows run program send images throw out error [\#427](https://github.com/wechaty/wechaty/issues/427)
- group names have HTML in them [\#382](https://github.com/wechaty/wechaty/issues/382)
- jsdoc2md may flush some pieces of the embedded doc [\#378](https://github.com/wechaty/wechaty/issues/378)
- Secure WebSocket\(wss\) do not work with Self Signed Certificate in PhantomJS  [\#12](https://github.com/wechaty/wechaty/issues/12)

**Merged pull requests:**

- fix: fix vscode setting, and close autoFixOnSave [\#844](https://github.com/wechaty/wechaty/pull/844) ([binsee](https://github.com/binsee))
- Add Hot Listener Support \(\#820\) [\#841](https://github.com/wechaty/wechaty/pull/841) ([huan](https://github.com/huan))
- Revert "Update express to the latest version 🚀" [\#831](https://github.com/wechaty/wechaty/pull/831) ([huan](https://github.com/huan))
- add \n after wiki [\#816](https://github.com/wechaty/wechaty/pull/816) ([lijiarui](https://github.com/lijiarui))
- Friendrequest doc [\#812](https://github.com/wechaty/wechaty/pull/812) ([lijiarui](https://github.com/lijiarui))
- Fix switch account [\#811](https://github.com/wechaty/wechaty/pull/811) ([binsee](https://github.com/binsee))
- fix\(package\): update brolog to version 1.2.6 [\#810](https://github.com/wechaty/wechaty/pull/810) ([huan](https://github.com/huan))
- change readme doc [\#805](https://github.com/wechaty/wechaty/pull/805) ([lijiarui](https://github.com/lijiarui))
- change doc order \# 774 [\#798](https://github.com/wechaty/wechaty/pull/798) ([lijiarui](https://github.com/lijiarui))
- fix\(\*\): Support for send 25Mb+ files [\#771](https://github.com/wechaty/wechaty/pull/771) ([binsee](https://github.com/binsee))
- Readme [\#757](https://github.com/wechaty/wechaty/pull/757) ([lijiarui](https://github.com/lijiarui))
- fix\(wechaty-bro\): resolved emit RECALLED type msg \(fix \#8\) [\#744](https://github.com/wechaty/wechaty/pull/744) ([binsee](https://github.com/binsee))
- add: Message.forward\(\) forward message [\#727](https://github.com/wechaty/wechaty/pull/727) ([binsee](https://github.com/binsee))
- add wechaty document [\#725](https://github.com/wechaty/wechaty/pull/725) ([lijiarui](https://github.com/lijiarui))

## [v0.8.2](https://github.com/wechaty/wechaty/tree/v0.8.2) (2017-05-03)

[Full Changelog](https://github.com/wechaty/wechaty/compare/v0.7.0...v0.8.2)

**Implemented enhancements:**

- Promote StateMonitor to a solo NPM module: StateSwitch [\#466](https://github.com/wechaty/wechaty/issues/466)
- Display detailed error trace when an error is caught in async  [\#360](https://github.com/wechaty/wechaty/issues/360)
- Room.find\({topic: topic}\) should allowed to return null [\#291](https://github.com/wechaty/wechaty/issues/291)
- add `room-bot-leave` event [\#250](https://github.com/wechaty/wechaty/issues/250)
- Prepare to rename the nick/remark/display for contact/room [\#217](https://github.com/wechaty/wechaty/issues/217)
- \[new feature\] add function message.mention\(\) [\#216](https://github.com/wechaty/wechaty/issues/216)
- \[new feature\] set bot's nickname in the group [\#201](https://github.com/wechaty/wechaty/issues/201)
- \[feature request\] fire `room-join` when someone joins from a QR Code [\#155](https://github.com/wechaty/wechaty/issues/155)
- \#4 send image/video [\#337](https://github.com/wechaty/wechaty/pull/337) ([mukaiu](https://github.com/mukaiu))

**Fixed bugs:**

- Reuse MediaMessage upload fail.Can be allowed MediaMessage reuse？ [\#439](https://github.com/wechaty/wechaty/issues/439)
- Room.member\(\) cannot find contact correctly [\#365](https://github.com/wechaty/wechaty/issues/365)
- Room.alias\(\) should return null if we have not set the alias in the room  [\#283](https://github.com/wechaty/wechaty/issues/283)
- Cannot read property 'Symbol\(Symbol.iterator\)' of undefined [\#273](https://github.com/wechaty/wechaty/issues/273)
- add sys message in FriendRequest Event  [\#260](https://github.com/wechaty/wechaty/issues/260)
- \[docker\] chromium-browser fail to start after upgrading chromium from v53 to v56 [\#235](https://github.com/wechaty/wechaty/issues/235)
- typo in Wiki [\#205](https://github.com/wechaty/wechaty/issues/205)
- doc bug [\#196](https://github.com/wechaty/wechaty/issues/196)
- Linting Error from PR@lijiarui [\#181](https://github.com/wechaty/wechaty/issues/181)
- \[document\] should list only the public/stable API to users [\#174](https://github.com/wechaty/wechaty/issues/174)

**Closed issues:**

- Always getSession timeout [\#463](https://github.com/wechaty/wechaty/issues/463)
- how to create more bots at once [\#460](https://github.com/wechaty/wechaty/issues/460)
- how do we get avatar link? [\#424](https://github.com/wechaty/wechaty/issues/424)
- can't run the example [\#423](https://github.com/wechaty/wechaty/issues/423)
- 有没有查找好友的方法？ [\#411](https://github.com/wechaty/wechaty/issues/411)
- ding-dong-bot-ts cannot run normally on Mac [\#410](https://github.com/wechaty/wechaty/issues/410)
- Failed due to EAI\_AGAIN registry.yarnpkg.com:443 [\#408](https://github.com/wechaty/wechaty/issues/408)
- cannot remark friend in centos system [\#406](https://github.com/wechaty/wechaty/issues/406)
- MediaMessage in ding-dong-bot example can not be create [\#399](https://github.com/wechaty/wechaty/issues/399)
- wechaty can auto receive money\(red envolop/transfer\) on account. [\#398](https://github.com/wechaty/wechaty/issues/398)
- \[bug\] room.say\(\) return contact's alias when bot set alias for some one [\#394](https://github.com/wechaty/wechaty/issues/394)
- `Room.fresh\(\)`not work; `Room.alias\(\)`returns null [\#391](https://github.com/wechaty/wechaty/issues/391)
- should add`phantomjs-prebuilt` in package.json [\#385](https://github.com/wechaty/wechaty/issues/385)
- error on room join: TypeError: room.topic is not a function [\#383](https://github.com/wechaty/wechaty/issues/383)
- problem starting docker container . SyntaxError: Unexpected token function [\#352](https://github.com/wechaty/wechaty/issues/352)
- \[discuss\] Rename Wechaty to Chatie? [\#346](https://github.com/wechaty/wechaty/issues/346)
- cannot send images / this.puppet.getBaseRequest is not a function [\#338](https://github.com/wechaty/wechaty/issues/338)
- Some strange log warn [\#336](https://github.com/wechaty/wechaty/issues/336)
- run bot in server,about 1 hour ago ,the process will be killed [\#330](https://github.com/wechaty/wechaty/issues/330)
- wechaty 0.7.21 works but 0.7.24 failed with Argument of type 'string | Promise\<boolean\>' is not assignable to parameter of type 'string'. [\#282](https://github.com/wechaty/wechaty/issues/282)
- how i can save avatar without await keywords? [\#278](https://github.com/wechaty/wechaty/issues/278)
- 如何获取MsgType为APP类型的信息,解析不成xml [\#262](https://github.com/wechaty/wechaty/issues/262)
- \[linting\] fix needed for new tslint rule: trailing-comma [\#251](https://github.com/wechaty/wechaty/issues/251)
- Avatar return empty image in example/contact-bot.ts [\#246](https://github.com/wechaty/wechaty/issues/246)
- Room&Contact.find\(\) should throw exception when it get more than one value [\#229](https://github.com/wechaty/wechaty/issues/229)
- Contact.findAll\(\) return contactList includes oa account [\#222](https://github.com/wechaty/wechaty/issues/222)
- timeouts when running unattended [\#184](https://github.com/wechaty/wechaty/issues/184)
- room.member\(\) cannot find contact when contact set whose alias in the room [\#173](https://github.com/wechaty/wechaty/issues/173)

**Merged pull requests:**

- Lazy to create a stream [\#470](https://github.com/wechaty/wechaty/pull/470) ([mukaiu](https://github.com/mukaiu))
- chore\(package\): update state-switch to version 0.1.7 [\#469](https://github.com/wechaty/wechaty/pull/469) ([huan](https://github.com/huan))
- chore\(package\): update bl to version 1.2.1 [\#462](https://github.com/wechaty/wechaty/pull/462) ([huan](https://github.com/huan))
- fix\(package\): update brolog to version 1.0.13 [\#455](https://github.com/wechaty/wechaty/pull/455) ([huan](https://github.com/huan))
- chore\(package\): update fluent-ffmpeg to version 2.1.2 [\#449](https://github.com/wechaty/wechaty/pull/449) ([huan](https://github.com/huan))
- add magic code for room.say\(\)  when `@bot ` happen [\#440](https://github.com/wechaty/wechaty/pull/440) ([lijiarui](https://github.com/lijiarui))
- \#3 support send gif [\#438](https://github.com/wechaty/wechaty/pull/438) ([mukaiu](https://github.com/mukaiu))
- Limit video file size [\#421](https://github.com/wechaty/wechaty/pull/421) ([mukaiu](https://github.com/mukaiu))
- add room.say\(MediaMessage\) [\#420](https://github.com/wechaty/wechaty/pull/420) ([mukaiu](https://github.com/mukaiu))
- Fix chrome driver path problem in Windows [\#416](https://github.com/wechaty/wechaty/pull/416) ([xjchengo](https://github.com/xjchengo))
- fix upload media url error [\#415](https://github.com/wechaty/wechaty/pull/415) ([mukaiu](https://github.com/mukaiu))
- support brand checking of contact  [\#404](https://github.com/wechaty/wechaty/pull/404) ([JasLin](https://github.com/JasLin))
- chore\(package\): update chromedriver to version 2.29.0 [\#396](https://github.com/wechaty/wechaty/pull/396) ([huan](https://github.com/huan))
- Add missing %s content for leaver not found error [\#388](https://github.com/wechaty/wechaty/pull/388) ([xinbenlv](https://github.com/xinbenlv))
- fix jsdoc flush issue \#378 and minor fix on the doc examples [\#380](https://github.com/wechaty/wechaty/pull/380) ([ax4](https://github.com/ax4))
- Limit the size of the sending file [\#376](https://github.com/wechaty/wechaty/pull/376) ([mukaiu](https://github.com/mukaiu))
- add room-leave event [\#370](https://github.com/wechaty/wechaty/pull/370) ([lijiarui](https://github.com/lijiarui))
- room.memberAll\(\) & change room.member\(\) query to 3 types [\#364](https://github.com/wechaty/wechaty/pull/364) ([lijiarui](https://github.com/lijiarui))
- Add mention [\#362](https://github.com/wechaty/wechaty/pull/362) ([lijiarui](https://github.com/lijiarui))
- Printout entire error trace when unhandledRejection was caught [\#361](https://github.com/wechaty/wechaty/pull/361) ([xinbenlv](https://github.com/xinbenlv))
- first item of memberList as owner is confusion [\#358](https://github.com/wechaty/wechaty/pull/358) ([JasLin](https://github.com/JasLin))
- chore\(package\): update ts-node to version 3.0.2 [\#351](https://github.com/wechaty/wechaty/pull/351) ([huan](https://github.com/huan))
- fix room test [\#328](https://github.com/wechaty/wechaty/pull/328) ([lijiarui](https://github.com/lijiarui))
- remove blank [\#324](https://github.com/wechaty/wechaty/pull/324) ([lijiarui](https://github.com/lijiarui))
- remove m.send\(\) fucntion [\#323](https://github.com/wechaty/wechaty/pull/323) ([lijiarui](https://github.com/lijiarui))
- Add JsDoc for Class Contact [\#321](https://github.com/wechaty/wechaty/pull/321) ([lijiarui](https://github.com/lijiarui))
- 291 [\#318](https://github.com/wechaty/wechaty/pull/318) ([lijiarui](https://github.com/lijiarui))
- chore\(package\): update yarn to version 0.21.3 [\#317](https://github.com/wechaty/wechaty/pull/317) ([huan](https://github.com/huan))
- chore\(package\): update nyc to version 10.1.2 [\#316](https://github.com/wechaty/wechaty/pull/316) ([huan](https://github.com/huan))
- chore\(package\): update tslint to version 4.5.1 [\#315](https://github.com/wechaty/wechaty/pull/315) ([huan](https://github.com/huan))
- chore\(package\): update check-node-version to version 2.0.1 [\#314](https://github.com/wechaty/wechaty/pull/314) ([huan](https://github.com/huan))
- chore\(package\): update @types/ws to version 0.0.38 [\#313](https://github.com/wechaty/wechaty/pull/313) ([huan](https://github.com/huan))
- chore\(package\): update @types/node to version 7.0.7 [\#312](https://github.com/wechaty/wechaty/pull/312) ([huan](https://github.com/huan))
- fix\(package\): update @types/selenium-webdriver to version 3.0.0 [\#311](https://github.com/wechaty/wechaty/pull/311) ([huan](https://github.com/huan))
- added hot load bots [\#310](https://github.com/wechaty/wechaty/pull/310) ([Gcaufy](https://github.com/Gcaufy))
- \#283 [\#303](https://github.com/wechaty/wechaty/pull/303) ([lijiarui](https://github.com/lijiarui))
- \#291 change `throw error` to `return null` [\#292](https://github.com/wechaty/wechaty/pull/292) ([lijiarui](https://github.com/lijiarui))

## [v0.7.0](https://github.com/wechaty/wechaty/tree/v0.7.0) (2016-12-29)

[Full Changelog](https://github.com/wechaty/wechaty/compare/v0.6.0...v0.7.0)

**Implemented enhancements:**

- 请问可以获取联系人或群成员的性别、所属地域、头像吗？ [\#121](https://github.com/wechaty/wechaty/issues/121)
- Function Room.add\(\) should return Promise\<boolean\> [\#119](https://github.com/wechaty/wechaty/issues/119)
- Could you add api to find contact by remark [\#117](https://github.com/wechaty/wechaty/issues/117)
- Need to support AppMsgType: 100001 with MsgType: 49 [\#114](https://github.com/wechaty/wechaty/issues/114)
- get room owner on event 'room-join','room-topic' [\#105](https://github.com/wechaty/wechaty/pull/105) ([JasLin](https://github.com/JasLin))

**Fixed bugs:**

- to silence all the output from webdriver\(chromedriver\) for log level INFO [\#150](https://github.com/wechaty/wechaty/issues/150)
- `tsc` compiling error: Cannot find namespace 'webdriver' [\#136](https://github.com/wechaty/wechaty/issues/136)
- remark\(null\) doesn't work [\#130](https://github.com/wechaty/wechaty/issues/130)
- Cannot identify \['\] in room topic [\#116](https://github.com/wechaty/wechaty/issues/116)
- room.member\(\) cannot get member when bot set remark for friend [\#104](https://github.com/wechaty/wechaty/issues/104)
- contactFind\(function \(c\) { return /.\*/.test\(c\) }\) rejected: javascript error: Unexpected token [\#98](https://github.com/wechaty/wechaty/issues/98)
- Error: Chrome failed to start: was killed [\#95](https://github.com/wechaty/wechaty/issues/95)
- Function `message.to\(\): Contact|Room` bug [\#88](https://github.com/wechaty/wechaty/issues/88)
- Session Cookies not loaded correctly? [\#31](https://github.com/wechaty/wechaty/issues/31)

**Closed issues:**

- too many levels of symbolic links [\#165](https://github.com/wechaty/wechaty/issues/165)
- node dist/example/ding-dong-bot.js example运行异常 [\#159](https://github.com/wechaty/wechaty/issues/159)
- deploying to server problems \(running headless\) [\#154](https://github.com/wechaty/wechaty/issues/154)
- wechaty mybot.js start error [\#126](https://github.com/wechaty/wechaty/issues/126)
- Room-join' para  inviteeList\[\] cannot always work well when contain emoji [\#125](https://github.com/wechaty/wechaty/issues/125)
- \[help\] install wechaty and its types [\#124](https://github.com/wechaty/wechaty/issues/124)
- ERR Message ready\(\) exception: Error: Contact.load\(\): id not found [\#123](https://github.com/wechaty/wechaty/issues/123)
- enhance request.hello function [\#120](https://github.com/wechaty/wechaty/issues/120)
- 无法自动通过好友请求 [\#115](https://github.com/wechaty/wechaty/issues/115)
- \[EVENT INVITATION\] Welcome to join Beijing Node Party 18: Wechaty & ChatBot on 11th Dec. [\#107](https://github.com/wechaty/wechaty/issues/107)
- another problem about docker run [\#103](https://github.com/wechaty/wechaty/issues/103)
-  Error: Server terminated early with status 127 [\#102](https://github.com/wechaty/wechaty/issues/102)
- failed run demo in docker under centos [\#101](https://github.com/wechaty/wechaty/issues/101)
- Wechaty.send\(\) error when send message to the room [\#89](https://github.com/wechaty/wechaty/issues/89)
- 基础运行报错.....我都有点不好意思问了.....汗.... [\#82](https://github.com/wechaty/wechaty/issues/82)

**Merged pull requests:**

- chore\(package\): update @types/node to version 6.0.54 [\#168](https://github.com/wechaty/wechaty/pull/168) ([huan](https://github.com/huan))
- chore\(package\): update tslint to version 4.2.0 [\#158](https://github.com/wechaty/wechaty/pull/158) ([huan](https://github.com/huan))
- chore\(package\): update @types/selenium-webdriver to version 2.53.37 [\#149](https://github.com/wechaty/wechaty/pull/149) ([huan](https://github.com/huan))
- chore\(package\): update tslint to version 4.1.1 [\#146](https://github.com/wechaty/wechaty/pull/146) ([huan](https://github.com/huan))
- chore\(package\): update @types/sinon to version 1.16.33 [\#143](https://github.com/wechaty/wechaty/pull/143) ([huan](https://github.com/huan))
- chore\(package\): update @types/node to version 6.0.52 [\#142](https://github.com/wechaty/wechaty/pull/142) ([huan](https://github.com/huan))
- chore\(package\): update tslint to version 4.1.0 [\#141](https://github.com/wechaty/wechaty/pull/141) ([huan](https://github.com/huan))
- Update README.md [\#139](https://github.com/wechaty/wechaty/pull/139) ([lijiarui](https://github.com/lijiarui))
- qrcode [\#112](https://github.com/wechaty/wechaty/pull/112) ([lijiarui](https://github.com/lijiarui))
- Update README.md [\#110](https://github.com/wechaty/wechaty/pull/110) ([lijiarui](https://github.com/lijiarui))
- fixed javascript error: attempt is not defined [\#100](https://github.com/wechaty/wechaty/pull/100) ([JasLin](https://github.com/JasLin))
- convert wechaty-bro.js to plain old javascript syntax \#60 [\#97](https://github.com/wechaty/wechaty/pull/97) ([cherry-geqi](https://github.com/cherry-geqi))

## [v0.6.0](https://github.com/wechaty/wechaty/tree/v0.6.0) (2016-11-11)

[Full Changelog](https://github.com/wechaty/wechaty/compare/v0.5.22...v0.6.0)

**Fixed bugs:**

- \[Docker\] Config.isDocker is not right in some Docker version / Linux distribution [\#84](https://github.com/wechaty/wechaty/issues/84)

## [v0.5.22](https://github.com/wechaty/wechaty/tree/v0.5.22) (2016-11-10)

[Full Changelog](https://github.com/wechaty/wechaty/compare/v0.5.9...v0.5.22)

**Implemented enhancements:**

- To Disable WebDriverJS promise manager for Selenium v3.0 [\#72](https://github.com/wechaty/wechaty/issues/72)
- \[Upgrade to v0.5\] Convert code base to Typescript from Javascript [\#40](https://github.com/wechaty/wechaty/issues/40)

**Closed issues:**

- can't run demo in docker under mac [\#80](https://github.com/wechaty/wechaty/issues/80)
- 在windows下运行例子,npm 环境中,报错关于getChromeDriver\(\) [\#77](https://github.com/wechaty/wechaty/issues/77)

## [v0.5.9](https://github.com/wechaty/wechaty/tree/v0.5.9) (2016-11-07)

[Full Changelog](https://github.com/wechaty/wechaty/compare/v0.5.1...v0.5.9)

**Closed issues:**

- run on windows.error [\#75](https://github.com/wechaty/wechaty/issues/75)

**Merged pull requests:**

- fix: memberList Method have no 'name' argument defined ,it'will cause a undefined error. [\#78](https://github.com/wechaty/wechaty/pull/78) ([JasLin](https://github.com/JasLin))
- fix issue \#70  [\#76](https://github.com/wechaty/wechaty/pull/76) ([JasLin](https://github.com/JasLin))

## [v0.5.1](https://github.com/wechaty/wechaty/tree/v0.5.1) (2016-11-03)

[Full Changelog](https://github.com/wechaty/wechaty/compare/v0.4.0...v0.5.1)

**Implemented enhancements:**

- Dockerize Wechaty for easy start [\#66](https://github.com/wechaty/wechaty/issues/66)
- Wechat帐号界面语言设为中文环境下：wechaty的room-join room-leave room-topic 事件无法触发 [\#52](https://github.com/wechaty/wechaty/issues/52)
- test/fix Watchdog with browser dead & timeout conditions [\#47](https://github.com/wechaty/wechaty/issues/47)
- use StateMonitor to record&check wechaty/puppet/bridge/browser state change [\#46](https://github.com/wechaty/wechaty/issues/46)
- \[New Feature\] send message by branding new method: say\(\) [\#41](https://github.com/wechaty/wechaty/issues/41)
- \[New Feature\] Contact.{tag,star,remark,find,findAll} [\#34](https://github.com/wechaty/wechaty/issues/34)
- \[New Feature\] FriendRequest class and event [\#33](https://github.com/wechaty/wechaty/issues/33)
- \[New Feature\] Room.{create,addMember,delMember,quit,modTopic} support [\#32](https://github.com/wechaty/wechaty/issues/32)

**Fixed bugs:**

- Just have a try as example of tuling bot. But method message.self\(\) seems work improper.   [\#68](https://github.com/wechaty/wechaty/issues/68)
- 在cloud9中运行wechaty报错 [\#67](https://github.com/wechaty/wechaty/issues/67)
- 当用户昵称中含有表情时，无法触发room-join 事件 [\#64](https://github.com/wechaty/wechaty/issues/64)
- room-join 事件下，无法通过contact.id 方法获取contact\_id [\#54](https://github.com/wechaty/wechaty/issues/54)
- FriendRequest is not export to npm module  [\#50](https://github.com/wechaty/wechaty/issues/50)

**Closed issues:**

- Run wechaty occurs chromedriver is still running and the solution [\#62](https://github.com/wechaty/wechaty/issues/62)
- Can't run wechaty with error log [\#61](https://github.com/wechaty/wechaty/issues/61)
- \[design\] new class: BrowserCookie [\#59](https://github.com/wechaty/wechaty/issues/59)
- 在room中通过room.topic\(\)获取不到room的topic [\#55](https://github.com/wechaty/wechaty/issues/55)
- 近期wechaty启动失败次数较多 [\#53](https://github.com/wechaty/wechaty/issues/53)
- TSError: ⨯ Unable to compile TypeScript src/puppet-web/event.ts \(120,12\): Type 'PuppetWeb' is not assignable to type 'void'. \(2322\) [\#51](https://github.com/wechaty/wechaty/issues/51)
- demo 无法运行 [\#49](https://github.com/wechaty/wechaty/issues/49)
- Suggest give an api to get url [\#45](https://github.com/wechaty/wechaty/issues/45)
- element\_wrong----contact.get\('name'\) got room name not contact name [\#43](https://github.com/wechaty/wechaty/issues/43)
- webdrive login always occur error, for one success login always cost 4-5 log trys [\#42](https://github.com/wechaty/wechaty/issues/42)

## [v0.4.0](https://github.com/wechaty/wechaty/tree/v0.4.0) (2016-10-08)

[Full Changelog](https://github.com/wechaty/wechaty/compare/v0.2.0...v0.4.0)

**Implemented enhancements:**

- \[Feature Request\] Add friend\(Contact\) to a group\(Room\) [\#14](https://github.com/wechaty/wechaty/issues/14)
- Support Friend Request / Contact Add & Del [\#6](https://github.com/wechaty/wechaty/issues/6)

**Fixed bugs:**

- Wechaty account logout unexpectedly [\#37](https://github.com/wechaty/wechaty/issues/37)
- google-chrome fails to start in docker [\#26](https://github.com/wechaty/wechaty/issues/26)
- wx.qq.com detect phantomjs and disabled it [\#21](https://github.com/wechaty/wechaty/issues/21)

**Closed issues:**

- get rid of `PuppetWeb.initAttach` [\#35](https://github.com/wechaty/wechaty/issues/35)
- webdriver fail in docker when use ava \(parallel tests mode\) [\#27](https://github.com/wechaty/wechaty/issues/27)
- WARN PuppetWebBridge init\(\) inject FINAL fail [\#22](https://github.com/wechaty/wechaty/issues/22)
- node-tap strange behaviour cause CircleCI & Travis-CI keep failing [\#11](https://github.com/wechaty/wechaty/issues/11)

**Merged pull requests:**

- add hubot introduction in readme [\#38](https://github.com/wechaty/wechaty/pull/38) ([lijiarui](https://github.com/lijiarui))
- Ava [\#25](https://github.com/wechaty/wechaty/pull/25) ([huan](https://github.com/huan))

## [v0.2.0](https://github.com/wechaty/wechaty/tree/v0.2.0) (2016-06-28)

[Full Changelog](https://github.com/wechaty/wechaty/compare/v0.1.1...v0.2.0)

## [v0.1.1](https://github.com/wechaty/wechaty/tree/v0.1.1) (2016-06-09)

[Full Changelog](https://github.com/wechaty/wechaty/compare/v0.0.6...v0.1.1)

**Fixed bugs:**

- ding-dong bot broken due to typo [\#5](https://github.com/wechaty/wechaty/issues/5)

## [v0.0.6](https://github.com/wechaty/wechaty/tree/v0.0.6) (2016-05-15)

[Full Changelog](https://github.com/wechaty/wechaty/compare/v0.0.5...v0.0.6)

**Closed issues:**

- selenium-webdriver & phantomjs-prebuilt not work together under win32 [\#1](https://github.com/wechaty/wechaty/issues/1)

**Merged pull requests:**

- Add a Gitter chat badge to README.md [\#3](https://github.com/wechaty/wechaty/pull/3) ([gitter-badger](https://github.com/gitter-badger))

## [v0.0.5](https://github.com/wechaty/wechaty/tree/v0.0.5) (2016-05-11)

[Full Changelog](https://github.com/wechaty/wechaty/compare/292f50456e3bd6cb9849218348ee053c76b1d6b3...v0.0.5)



\* *This Changelog was automatically generated by [github_changelog_generator](https://github.com/github-changelog-generator/github-changelog-generator)*
